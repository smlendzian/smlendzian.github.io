#ifndef Bookcase_h
#define Bookcase_h

#include "Task.h"

//Bookcase is a type of Task that owns a PressurePlate Button and a Servo
//(used for the Bookcase Puzzle)
class Bookcase : public Task
{
    public:
    Button PressurePlate;

    Bookcase();

    //Keeps checking whether the PressurePlate button is released until it is
    //Then it moves the Servo to open the physical bookcase and ends the Task
    virtual void Run();
};

#endif