#include "Sprites.h"

Sprite::Sprite(int x_val, int y_val, int w, int h)
:Control(x_val, y_val, w, h)
{

}

void Sprite::Draw()
{
    for(int row = 0; row < height; ++row)
    {
        for(int column = 0; column < width; ++column)
        {
            int color = array[row][column];

            if(color != -1)
            {
                LCD.SetDrawColor(color);
                LCD.DrawPixel(y_start + column, x_start + row);
            }
        }
    }
}

CharacterSprite::CharacterSprite(CharacterSpriteName character_sprite_name, int x_val, int y_val, int scaling_factor_val)
:Sprite(x_val, y_val, 0, 0),
 scaling_factor(scaling_factor_val)
{
    //Loads text file for the Sprite for the character/power and stores it in a 2-Dimensional Array.
    switch(character_sprite_name)
    {
        case Brooke:
        {
            array = vector< vector<int> > 
            {
                #include "Brooke.txt" 
            };
        }
        break;
        case Erin:
        {
            array = vector< vector<int> > 
            {
                #include "Erin.txt" 
            };
        }
        break;
        case Jimmy:
        {
            array = vector< vector<int> > 
            {
                #include "Jimmy.txt" 
            };
        }
        break;
        case Kyle:
        {
            array = vector< vector<int> > 
            {
                #include "Kyle.txt" 
            };
        }
        break;
        case Riley:
        {
            array = vector< vector<int> > 
            {
                #include "Riley.txt" 
            };
        }
        break;
        case Gamer:
        {
            array = vector< vector<int> > 
            {
                #include "Gamer.txt" 
            };
        }
        break;
        case TommPizza:
        {
            array = vector< vector<int> > 
            {
                #include "TommPizza.txt" 
            };
        }
        break;
        case Ladybug:
        {
            array = vector< vector<int> > 
            {
                #include "Ladybug.txt" 
            };
        }
        break;
        case Cat:
        {
            array = vector< vector<int> > 
            {
                #include "Cat.txt" 
            };
        }
        break;
        case Oatmeal:
        {
            array = vector< vector<int> > 
            {
                #include "Oatmeal.txt" 
            };
        }
        break;
        case Eggo:
        {
            array = vector< vector<int> > 
            {
                #include "Eggo.txt" 
            };
        }
        break;
        case Teleport:
        {
            array = vector< vector<int> > 
            {
                #include "Teleport.txt" 
            };
        }
        break;
        case Coffee:
        {
            array = vector< vector<int> > 
            {
                #include "Coffee.txt" 
            };
        }
        break;
    }

    //Determines the height of the Sprite from the array (the number of rows of the array).
    height = array.size();

    //Determines the width of the Sprite from the array (the number of columns of the array)
    //(if the file loads properly as a precaution).
    if(height > 0)
        width = array[0].size();
}

void CharacterSprite::Draw()
{
    for(int row = 0; row < height; ++row)
    {
        for(int column = 0; column < width; ++column)
        {
            int color = array[row][column];

            if(color != -1)
            {
                LCD.SetDrawColor(color);
                LCD.FillRectangle(y_start + column * scaling_factor, x_start + row * scaling_factor, scaling_factor, scaling_factor);
            }
        }
    }
}

TeacupSprite::TeacupSprite(int x_val, int y_val)
:Sprite(x_val, y_val, 0, 0)
{
    //Loads text file for the Sprite and stores it in a 2-Dimensional Array.
    array = vector< vector<int> > 
    {
        #include "Teacup.txt" 
    };

    //Determines the height of the Sprite from the array (the number of rows of the array).
    height = array.size();

    //Determines the width of the Sprite from the array (the number of columns of the array)
    //(if the file loads properly as a precaution).
    if(height > 0)
        width = array[0].size();    
}

QRSprite::QRSprite(int x_val, int y_val, int scaling_factor_val)
:Sprite(x_val, y_val, 0, 0),
 scaling_factor(scaling_factor_val)
{
    //Loads text file for the Sprite and stores it in a 2-Dimensional Array.
    array = vector< vector<int> > 
    {
        #include "QR.txt" 
    };

    //Determines the height of the Sprite from the array (the number of rows of the array).
    height = array.size();

    //Determines the width of the Sprite from the array (the number of columns of the array)
    //(if the file loads properly as a precaution).
    if(height > 0)
        width = array[0].size();    
}

void QRSprite::Draw()
{
    for(int row = 0; row < height; ++row)
    {
        for(int column = 0; column < width; ++column)
        {
            int color = array[row][column];

            if(color != -1)
            {
                LCD.SetDrawColor(color);
                LCD.FillRectangle(y_start + column * scaling_factor, x_start + row * scaling_factor, scaling_factor, scaling_factor);
            }
        }
    }
}