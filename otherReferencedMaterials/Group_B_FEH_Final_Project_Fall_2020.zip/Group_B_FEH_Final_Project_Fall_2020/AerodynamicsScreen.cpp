#include "AerodynamicsScreen.h"

AerodynamicsScreen::AerodynamicsScreen()
:text("Instructions:", MAX_X/2, 50, MAX_X, CHAR_HEIGHT, LCD.Black),
text1("There are 4 buttons", MAX_X/2, 65, MAX_X, CHAR_HEIGHT, LCD.Black),
text2("each controls a force of flight", MAX_X/2, 80, MAX_X, CHAR_HEIGHT, LCD.Black),
text3("Use the Control Buttons to", MAX_X/2, 95, MAX_X, CHAR_HEIGHT, LCD.Black),
text4("intersect the aircraft nose with the box", MAX_X/2 +7, 110, MAX_X, CHAR_HEIGHT, LCD.Black),
text5("Some buttons may not be helpful!", MAX_X/2 +5, 125, MAX_X, CHAR_HEIGHT, LCD.Black),
 X("X", MAX_X - CHAR_WIDTH, 4, CHAR_WIDTH, CHAR_HEIGHT, LCD.Black, LCD.Red, LCD.Red),
 StartAero("START", MAX_X/2 - 8 - CHAR_WIDTH, 152, CHAR_WIDTH*6, CHAR_HEIGHT, LCD.Black, LCD.Black, LCD.Gray)
{

}

void AerodynamicsScreen::DrawScreen()
{
    LCD.Clear(LCD.Red);
    
    text.Draw();
    text1.Draw();
    text2.Draw();
    text3.Draw();
    text4.Draw();
    text5.Draw();
    X.Draw();
    StartAero.Draw();
}

void AerodynamicsScreen::ScreenTouched(int x, int y)
{
   if(X.WasControlTouched(x,y))
   {
       ShouldExitScreen = true;
   }
   else if(StartAero.WasControlTouched(x,y))
   {
       aerogame.StartScreen();
   }
}
