#ifndef SpotSpeedGameScreen_h 
#define SpotSpeedGameScreen_h 

#include "Screen.h"

/*This class is for the buttons and the textboxes on the game screen*/
class SpotSpeedGameScreen : public Screen 
{
   private: 
   Button X;
   TextBox SpotSpeed;
   Button Press;

   public:

   SpotSpeedGameScreen();

   void DrawScreen();
   void ScreenTouched(int x, int y);
};

#endif