#ifndef AerodynamicsScreen_h 
#define AerodynamicsScreen_h 

#include "Screen.h"
#include "AeroDynamicsScreenGame.h"

//After clicking the appropriate Button on the MinigamesMenuScreen, the player is brought to this Screen.
class AerodynamicsScreen : public Screen 
{
   private:
   TextBox text; 
   TextBox text1;
   TextBox text2;
   TextBox text3;
   TextBox text4;
   TextBox text5;
   Button X;
   Button StartAero;
   AerodynamicsScreenGame aerogame;

   public:

   AerodynamicsScreen();

   virtual void DrawScreen();
   virtual void ScreenTouched(int x, int y);
};

#endif