#include "FinalBattleClasses.h"

ProjectileTextBox::ProjectileTextBox(const char*text_val, int x_val, int y_val, int color)
:TextBox(text_val, x_val, y_val, 0, 0, color)
{
    width = len * CHAR_WIDTH + 40;
    height = CHAR_HEIGHT + 2;

    x_start = x - width/2;
    y_start = y - height/2;
}

void ProjectileTextBox::Animate(int x_final, int y_final, int y_max, float time_interval, int background_color)
{
    //Everything is made a float here to make calculations easier.
    float time = 0, x_initial = x, y_initial = y, x_current, y_current, x_final_float = x_final, y_final_float = y_final, max_y_float = y_max;

    //Using kinematic equations (+y is downwards and +x is to the right):
    //g = (0 - (-v_i_y)) / t_max
    //t_max = v_i_y / g
    //y_max = y_i - v_i_y * t_max + (g/2) * t_max^2
    //y_max = y_i - v_i_y * (v_i_y / g) + (g/2) * (v_i_y / g)^2
    //y_max = y_i - (v_i_y)^2 / g + (v_i_y)^2 / (2g)
    //y_max - y_i = (v_i_y)^2 / (-2g)
    //(v_iy)^2 = -2g(y_max - y_i)
    float v_i_y = sqrt(-2.0 * ACCELERATION_OF_GRAVITY * (y_max - y_initial));
    //y_f = y_i - v_i_y * t_f + (g/2) * (t_f)^2
    //(g/2) * (t_f)^2 - v_i_y * t_f - y_f + y_i = 0
    //Using the quadratic formula:
    float t_final = (v_i_y + sqrt(v_i_y * v_i_y - 4.0 * (ACCELERATION_OF_GRAVITY / 2.0) * (y_initial - y_final_float))) / ACCELERATION_OF_GRAVITY;
    //Using the definition of velocity:
    float v_i_x = (x_final_float - x_initial) / t_final;

    while(time < t_final)
    {
        Draw();

        Sleep(time_interval);

        time += time_interval;

        Control::UnDraw(background_color);

        //Use kinematic equations to find the next location.
        x_current = x_initial + v_i_x * time;
        y_current = y_initial - v_i_y * time + (ACCELERATION_OF_GRAVITY / 2) * time * time;

        Control::UpdateLocation(x_current, y_current);
    }
}

FinalBattleCharacter::FinalBattleCharacter()
:character_sprite(CharacterSprite::Brooke, 0, 0, 2)
{
    
}

FinalBattlePlayerCharacter::FinalBattlePlayerCharacter()
:power_sprite(CharacterSprite::Brooke, 0, 0, 2)
{

}

void FinalBattleCharacter::SetCharacter(CharacterName character_val, int initial_health)
{
    character = character_val;
    health = initial_health;
}

int FinalBattleCharacter::GetCharacter()
{
    return character;
}

void FinalBattleCharacter::SetHealth(int health_val)
{
    health = health_val;
}

int FinalBattleCharacter::GetHealth()
{
    return health;
}

void FinalBattleCharacter::SubtractFromHealth(int health_lost)
{
    health -= health_lost;
}

void FinalBattleCharacter::AddToHealth(int health_gained)
{
    health += health_gained;
}

void FinalBattleCharacter::SetProjectileText(const char*text_val)
{
    text = text_val;
}

void FinalBattleCharacter::SetProjectileTextInitialPosition(int x_i_val, int y_i_val)
{
    x_i = x_i_val;
    y_i = y_i_val;
}

void FinalBattleCharacter::SetProjectileTextFinalPosition(int x_f_val, int y_f_val)
{
    x_f = x_f_val;
    y_f = y_f_val;
}

void FinalBattleCharacter::SetProjectileTextMaxY(int y_max_val)
{
    y_max = y_max_val;
}

void FinalBattleCharacter::SetProjectileTextTimeInterval(float time_interval_val)
{
    time_interval = time_interval_val;
}

void FinalBattleCharacter::SetProjectileTextColors(int text_color_val, int background_color_val)
{
    text_color = text_color_val;
    background_color = background_color_val;
}

int FinalBattleCharacter::Attack(int min_base_damage, int max_base_damage, float multiplier, float power_multiplier, int miss_rate)
{
    //Attacking Animation:
    ProjectileTextBox attack_text(text, x_i, y_i, text_color);
    attack_text.Animate(x_f, y_f, y_max, time_interval, background_color);

    //A random amount of base damage is generated between the specified minimum and maximum base damage.
    int base_damage = (RandInt() % max_base_damage) + 1;
    if (base_damage < min_base_damage)
    {
        base_damage = min_base_damage;
    };

    //Convert the base damage to a float so integer math is not used when applying the multiplier.
    float base_damage_float = base_damage;

    float damage_float = base_damage_float * multiplier * power_multiplier;

    int damage = damage_float;

    //A random number is generated between 0 and 100.
    int rand_miss = RandInt() % 101;

    if(rand_miss < miss_rate)
    {
        TextBox miss("DODGE", MAX_X/2, MAX_Y/2, MAX_X, CHAR_HEIGHT, LCD.Black);
        miss.Draw();
        Sleep(3.0);
        miss.UnDraw(LCD.Red);

        damage = 0;
    }

    return damage;
}

void FinalBattleCharacter::Heal(int min_base_heal, int max_base_heal, float multiplier)
{
    //A random amount of base healing is generated between the specified minimum and maximum base healing.
    int base_heal = RandInt() % max_base_heal + 1; 
    if (base_heal < min_base_heal)
    {
        base_heal = min_base_heal;
    }

    //Convert the base healing to a float so integer math is not used when applying the multiplier.
    float base_heal_float = base_heal;

    float heal_amount = base_heal_float * multiplier;

    AddToHealth(heal_amount);
}

void FinalBattlePlayerCharacter::SetProjectileTextBoxToDefault()
{
    FinalBattleCharacter::SetProjectileText("TEA");
    FinalBattleCharacter::SetProjectileTextInitialPosition(40, MAX_Y - 120);
    FinalBattleCharacter::SetProjectileTextFinalPosition(MAX_X - 40, MAX_Y - 110);
    FinalBattleCharacter::SetProjectileTextMaxY(75);
    FinalBattleCharacter::SetProjectileTextTimeInterval(1.0);
    FinalBattleCharacter::SetProjectileTextColors(LCD.Black, LCD.Red);
}

void FinalBattleEnemyCharacter::SetProjectileTextBoxToDefault()
{
    FinalBattleCharacter::SetProjectileTextInitialPosition(MAX_X - 40, MAX_Y - 110);
    FinalBattleCharacter::SetProjectileTextFinalPosition(40, MAX_Y - 120);
    FinalBattleCharacter::SetProjectileTextMaxY(75);
    FinalBattleCharacter::SetProjectileTextTimeInterval(1.0);
    FinalBattleCharacter::SetProjectileTextColors(LCD.Black, LCD.Red);
}

void FinalBattlePlayerCharacter::DrawCharacter()
{
    switch(character)
    {
        case Brooke:
        {
            CharacterSprite character_sprite(CharacterSprite::Brooke, 130, 10, 2);
            CharacterSprite power_sprite(CharacterSprite::Cat, 150, 70, 2);
            character_sprite.Draw();
            power_sprite.Draw();
        }
        break;
        case Erin:
        {
            CharacterSprite character_sprite(CharacterSprite::Erin, 130, 10, 2);
            CharacterSprite power_sprite(CharacterSprite::Oatmeal, 150, 70, 2);
            character_sprite.Draw();
            power_sprite.Draw();
        }
        break;
        case Jimmy:
        {
            CharacterSprite character_sprite(CharacterSprite::Jimmy, 130, 10, 2);
            CharacterSprite power_sprite(CharacterSprite::Eggo, 150, 70, 2);
            character_sprite.Draw();
            power_sprite.Draw();
        }
        break;
        case Kyle:
        {
            CharacterSprite character_sprite(CharacterSprite::Kyle, 130, 10, 2);
            CharacterSprite power_sprite(CharacterSprite::Teleport, 150, 70, 2);
            character_sprite.Draw();
            power_sprite.Draw();
        }
        break;
        case Riley:
        {
            CharacterSprite character_sprite(CharacterSprite::Riley, 130, 10, 2);
            CharacterSprite power_sprite(CharacterSprite::Coffee, 150, 70, 2);
            character_sprite.Draw();
            power_sprite.Draw();
        }
        break;
    }
}

void FinalBattleEnemyCharacter::DrawCharacter()
{
    switch(character)
    {
        case Gamer:
        {
            CharacterSprite character_sprite(CharacterSprite::Gamer, 160, MAX_X - 60, 2);
            character_sprite.Draw();
        }
        break;
        case TommPizza:
        {
            CharacterSprite character_sprite(CharacterSprite::TommPizza, 160, MAX_X - 60, 2);
            character_sprite.Draw();
        }
        break;
        case Ladybug:
        {
            CharacterSprite character_sprite(CharacterSprite::Ladybug, 160, MAX_X - 60, 2);
            character_sprite.Draw();
        }
        break;
    }
}

void FinalBattlePlayerCharacter::UnDrawCharacter(int undraw_color)
{
    character_sprite.UnDraw(undraw_color);
    power_sprite.UnDraw(undraw_color);
}

void FinalBattleEnemyCharacter::UnDrawCharacter(int undraw_color)
{
    character_sprite.UnDraw(undraw_color);
}

void FinalBattleCharacter::DrawBoxAroundCharacter(int added_width, int added_height, int box_color)
{
    character_sprite.DrawBoxAround(added_width, added_height, box_color);
}

void FinalBattlePlayerCharacter::DrawBoxAroundPower(int added_width, int added_height, int box_color)
{
    power_sprite.DrawBoxAround(added_width, added_height, box_color);
}