#ifndef TrojanAndLogic_h
#define TrojanAndLogic_h

#include "Task.h" 

//TrojanAndLogic is a Task that includes everything needed to operate the electrical components involved during
//the Trojan Horse Puzzle and the Logic Puzzle
class TrojanAndLogic : public Task
{
    public:

    TrojanAndLogicCommunicator communicator;

    TrojanAndLogic();

    virtual void Run();
};

#endif