#include "SlidingBlocks.h"

//Name list for RAM conservation
const char PROGMEM SlidingBlocksName[] = "SlidingBlocks";
const char PROGMEM SlidingBlocksButton1Name[] = "SlidingBlocksButton1";
const char PROGMEM SlidingBlocksButton2Name[] = "SlidingBlocksButton2";
const char PROGMEM SlidingBlocksButton3Name[] = "SlidingBlocksButton3";
const char PROGMEM SlidingBlocksButton4Name[] = "SlidingBlocksButton4";
const char PROGMEM SlidingBlocksButton5Name[] = "SlidingBlocksButton5";
const char PROGMEM SlidingBlocksButton6Name[] = "SlidingBlocksButton6";
const char PROGMEM SlidingBlocksButton7Name[] = "SlidingBlocksButton7";
const char PROGMEM SlidingBlocksButton8Name[] = "SlidingBlocksButton8";
const char PROGMEM SlidingBlocksServoName[] = "SlidingBlocksServo";

SlidingBlocks::SlidingBlocks()
:Task(SlidingBlocksName),
SlidingBlocksButton1(SlidingBlocksButton1Name, DigitalSensor::Mux1, SlidingBlocksButton1Port),
SlidingBlocksButton2(SlidingBlocksButton2Name, DigitalSensor::Mux1, SlidingBlocksButton2Port),
SlidingBlocksButton3(SlidingBlocksButton3Name, DigitalSensor::Mux1, SlidingBlocksButton3Port),
SlidingBlocksButton4(SlidingBlocksButton4Name, DigitalSensor::Mux1, SlidingBlocksButton4Port),
SlidingBlocksButton5(SlidingBlocksButton5Name, DigitalSensor::Mux1, SlidingBlocksButton5Port),
SlidingBlocksButton6(SlidingBlocksButton6Name, DigitalSensor::Mux1, SlidingBlocksButton6Port),
SlidingBlocksButton7(SlidingBlocksButton7Name, DigitalSensor::Mux1, SlidingBlocksButton7Port),
SlidingBlocksButton8(SlidingBlocksButton8Name, DigitalSensor::Mux1, SlidingBlocksButton8Port)
{
    //Everything in this constructor is carried out when an instance of the SlidingBlocks class is created.
}

void SlidingBlocks::Run()
{
    //The number of the buttons is the order they'll be pressed in

    while(!ShouldEndTask) //Loop is redundant but used for clarity
    {
        communicator.RunCommunicator(Task::TimeWhenStartedTask);

        //Nested if-statements to ensure buttons are pressed in the correct order
        SlidingBlocksButton1.CheckWhetherButtonWasClicked();
        if(SlidingBlocksButton1.GetButtonWasPressedCorrectly())
        {
            SlidingBlocksButton2.CheckWhetherButtonWasClicked();
            if(SlidingBlocksButton2.GetButtonWasPressedCorrectly())
            {
                SlidingBlocksButton3.CheckWhetherButtonWasClicked();
                if(SlidingBlocksButton3.GetButtonWasPressedCorrectly())
                {
                    SlidingBlocksButton4.CheckWhetherButtonWasClicked();
                    if(SlidingBlocksButton4.GetButtonWasPressedCorrectly())
                    {
                        SlidingBlocksButton5.CheckWhetherButtonWasClicked();
                        if(SlidingBlocksButton5.GetButtonWasPressedCorrectly())
                        {
                            SlidingBlocksButton6.CheckWhetherButtonWasClicked();
                            if(SlidingBlocksButton6.GetButtonWasPressedCorrectly())
                            {
                                SlidingBlocksButton7.CheckWhetherButtonWasClicked();
                                if(SlidingBlocksButton7.GetButtonWasPressedCorrectly())
                                {
                                    SlidingBlocksButton8.CheckWhetherButtonWasClicked();
                                    if(SlidingBlocksButton8.GetButtonWasPressedCorrectly())
                                    {
                                        SlidingBlocksSolved();
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        /*
        //if-loop explanation: It only accepts the next appropriate button in the order. There's no consequence for
        //  pressing a wrong button (aka there's nothing like a restart for pressing the wrong button)
        //starts the ordered button press checking when the first button is pressed.
        */
    }
}

void SlidingBlocks::SlidingBlocksSolved()
{
    Serial.println(F("SlidingBlocksButton8 Released"));
    Serial.println(F("Sliding Block Puzzle completed! Unlock the Container."));

    {
        ServoDevice sliding_blocks_servo(SlidingBlocksServoName, SlidingBlocksServoPort, 180);
        sliding_blocks_servo.MoveToPosition(0); //Servo moves the door into its "open" position
        delay(3000);
    } //ServoDevice destructor is called after the closing curly brace

    Serial.println(F("ServoMotorToOpenedPosition"));

    ShouldEndTask = true; //Ends the loop in Task::Start() to return to the MainMenu
}

SlidingBlocksButton::SlidingBlocksButton(const char* PROGMEM name_val, PortLocation port_location_val, int port_num, long initial_state_val)
:Button(name_val, port_location_val, port_num, initial_state_val)
{

}

bool SlidingBlocksButton::GetButtonWasPressedCorrectly()
{
    return button_was_pressed_correctly;
}

void SlidingBlocksButton::SetButtonWasPressedCorrectly(bool button_was_pressed_correctly_val)
{
    button_was_pressed_correctly = button_was_pressed_correctly_val;
}

void SlidingBlocksButton::CheckWhetherButtonWasClicked()
{
    //Check whether the button was not pressed before but is pressed now.
    if(!ButtonWasPressed() && ButtonIsPressed())
    //Checks the previous reading variable, and then does a new reading
    //(changing that variable, so the order of this if statement is important)
    {
        Serial.print(Name());
        Serial.println(F("WasPressed"));
    }
    //Check whether the button was pressed before but is released now.
    else if(ButtonWasPressed() && ButtonIsReleased())
    {
        Serial.print(Name());
        Serial.println(F("WasReleased"));

        SetButtonWasPressedCorrectly(true);
    }
}



