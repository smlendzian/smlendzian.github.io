#ifndef TeaTimeScreen_h 
#define TeaTimeScreen_h 

#include "Screen.h"

//The TeaTimeScreen is drawn after the appropriate Button is unlocked (by winning the Final Battle) and clicked on the StatsScreen.
//The link and QR code for Drew's video are displayed here.
//The player can return to the StatsScreen.
class TeaTimeScreen : public Screen 
{
   private:
   TextBox congrats, you_won, link; 
   Button X;
   QRSprite qr_code;

   public:

   TeaTimeScreen();

   virtual void DrawScreen();
   virtual void ScreenTouched(int x, int y);
};

#endif