#include "TrojanAndLogic.h"

//Name list for RAM conservation
const char PROGMEM TrojanAndLogicName[] = "TrojanAndLogic";
const char PROGMEM TrojanAndLogicServoName[] = "TrojanAndLogicServo";

TrojanAndLogic::TrojanAndLogic()
:Task(TrojanAndLogicName)
{
    
}

void TrojanAndLogic::Run()
{
    while(!ShouldEndTask) //Loop is redundant but used for clarity
    {
        bool password_success = communicator.RunCommunicator(Task::TimeWhenStartedTask);

        if(password_success) 
        {
            Serial.println(F("PasswordSuccess"));

            {
                ServoDevice trojan_and_logic_servo(TrojanAndLogicServoName, TrojanAndLogicServoPort, 180);
                trojan_and_logic_servo.MoveToPosition(0); //Servo moves the door into its "open" position. 80
                delay(3000);
            } //ServoDevice destructor is called after the closing curly brace

            ShouldEndTask = true;   //Ends the loop in Task::Start() to return to the MainMenu
        }
    }
}