#include "MessagesToCommunicator.h"

//Name list for RAM conservation
const char PROGMEM TestMessage1Name[] = "TestMessage1";
const char PROGMEM TestHintMessage1Name[] = "TestHintMessage1";
const char PROGMEM TrojanMessage1Name[] = "TrojanMessage1";

MessageToCommunicator::MessageToCommunicator(const char* PROGMEM name_val, unsigned long time_to_share_message_val, int audio_file_num_val)
:name(name_val),
time_to_share_message(time_to_share_message_val),
audio_file_number(audio_file_num_val)
{
    
}

bool MessageToCommunicator::ItIsTimeToShareMessage(unsigned long time_when_started_task)
{
    return (time_to_share_message <= 
            TheTime.GetTimeSinceEscapeRoomStartedInMilliseconds() - time_when_started_task); 
}

void MessageToCommunicator::SetTimeOfStartText(unsigned long time_of_start_text_val)
{
    time_of_start_text = time_of_start_text_val;
}  

bool MessageToCommunicator::ItIsTimeToMoveToTheNextLine(unsigned long scroll_delay_in_milliseconds)
{
    return scroll_delay_in_milliseconds <= TheTime.GetTimeSinceEscapeRoomStartedInMilliseconds() - time_of_start_text;
}

bool MessageToCommunicator::PrintingIsInProgress()
{
    return printing_is_in_progress;
}

void MessageToCommunicator::SetPrintingIsInProgress(bool printing_is_in_progress_val)
{
    printing_is_in_progress = printing_is_in_progress_val;
}

/*TestMessage1::TestMessage1()
:MessageToCommunicator(TestMessage1Name, 0, 1)
{

}

void TestMessage1::RunMessage(LiquidCrystalShiftRegister& LCD, MP3& mp3)
{
    if(printing_is_in_progress)
    {
        if(!page_1_has_printed)
        {
            Serial.println(F("Message1Page1"));

            if(audio_file_number != -1)
            {
                mp3.Play(audio_file_number);
            }

            LCD.clear();
            LCD.setCursor(0,0); //line 1
            LCD.print(F("Hello World!"));
            LCD.setCursor(0,1); //line 2
            LCD.print(F("This message is"));

            SetTimeOfStartText(TheTime.GetTimeSinceEscapeRoomStartedInMilliseconds());
            page_1_has_printed = true;
        }
        else if(!page_2_has_printed && ItIsTimeToMoveToTheNextLine(2000))
        {
            Serial.println(F("Message1Page2"));
            
            LCD.clear();
            LCD.setCursor(0,0); //line 1
            LCD.print(F("Team 45's 1st"));
            LCD.setCursor(0,1); //line 2
            LCD.print(F("Escape Room"));

            page_2_has_printed = true;
        }
        else if(page_2_has_printed && !page_3_has_printed && ItIsTimeToMoveToTheNextLine(4000))
        {
            Serial.println(F("Message1Page3"));
            
            LCD.clear();
            LCD.setCursor(0,0); //line 1
            LCD.print(F("Test Message!"));
            LCD.setCursor(0,1); //line 2
            LCD.print(F(":-D"));

            page_3_has_printed = true;
        }
        else if(page_3_has_printed && ItIsTimeToMoveToTheNextLine(9000))
        {
            Serial.println(F("Message1Finished"));
            
            printing_is_in_progress = false;

            time_to_share_message = -1; //Max int
        }
    }
}

void TestMessage1::ResetPrintingPages()
{
    page_1_has_printed = false;
    page_2_has_printed = false;
    page_3_has_printed = false;
}

TestHintMessage1::TestHintMessage1()
:MessageToCommunicator(TestHintMessage1Name, MillisecondsInAMinute * 0.5, 2)
{
    
}

void TestHintMessage1::RunMessage(LiquidCrystalShiftRegister& LCD, MP3& mp3)
{
    if(printing_is_in_progress)
    {
        if(!page_1_has_printed)
        {
            Serial.println(F("HintMessage1Page1"));
            
            if(audio_file_number != -1)
            {
                mp3.Play(audio_file_number);
            }

            LCD.clear();
            LCD.setCursor(0,0); //line 1
            LCD.print(F("This message is"));
            LCD.setCursor(0,1); //line 2
            LCD.print(F("Team 45's 1st"));

            SetTimeOfStartText(TheTime.GetTimeSinceEscapeRoomStartedInMilliseconds());
            page_1_has_printed = true;
        }
        else if(!page_2_has_printed && ItIsTimeToMoveToTheNextLine(2000))
        {
            Serial.println(F("HintMessage1Page2"));
            
            LCD.clear();
            LCD.setCursor(0,0); //line 1
            LCD.print(F("Escape Room Hint"));
            LCD.setCursor(0,1); //line 2
            LCD.print(F("Test Message!"));

            page_2_has_printed = true;
        }
        else if(page_2_has_printed && !page_3_has_printed && ItIsTimeToMoveToTheNextLine(5000))
        {
            Serial.println(F("HintMessage1Page3"));
            
            LCD.clear();
            LCD.setCursor(0,0); //line 1
            LCD.print(F("Farewell World?"));
            LCD.setCursor(0,1); //line 2
            LCD.print(F("I guess. :-)"));

            page_3_has_printed = true;
        }
        else if(page_3_has_printed && ItIsTimeToMoveToTheNextLine(10000))
        {
            Serial.println(F("HintMessage1Finished"));
            
            printing_is_in_progress = false;

            time_to_share_message = -1; //Max int
        }
    }
}

void TestHintMessage1::ResetPrintingPages()
{
    page_1_has_printed = false;
    page_2_has_printed = false;
    page_3_has_printed = false;
}*/

SundialMessage1::SundialMessage1()
:MessageToCommunicator(TestMessage1Name, 0, 16)
{

}

void SundialMessage1::RunMessage(LiquidCrystalShiftRegister& LCD, MP3& mp3)
{
    if(printing_is_in_progress)
    {
        if(!page_1_has_printed)
        {
            Serial.println(F("SundialMessage1Page1"));

            if(audio_file_number != -1)
            {
                mp3.Play(audio_file_number);
            }

            LCD.clear();
            LCD.setCursor(0,0); //line 1
            LCD.print(F("This will be"));
            LCD.setCursor(0,1); //line 2
            LCD.print(F("the message for"));

            SetTimeOfStartText(TheTime.GetTimeSinceEscapeRoomStartedInMilliseconds());
            page_1_has_printed = true;
        }
        else if(!page_2_has_printed && ItIsTimeToMoveToTheNextLine(1500))
        {
            Serial.println(F("SundialMessage1Page2"));
            
            LCD.clear();
            LCD.setCursor(0,0); //line 1
            LCD.print(F("the Sundial"));
            LCD.setCursor(0,1); //line 2
            LCD.print(F("Puzzle. :-)"));

            page_2_has_printed = true;
        }
        else if(page_2_has_printed && ItIsTimeToMoveToTheNextLine(3000))
        {
            Serial.println(F("Message1Finished"));
            
            printing_is_in_progress = false;

            time_to_share_message = -1; //Max int
        }
    }
}

void SundialMessage1::ResetPrintingPages()
{
    page_1_has_printed = false;
    page_2_has_printed = false;
}

SundialHintMessage1::SundialHintMessage1()
:MessageToCommunicator(TestHintMessage1Name, MillisecondsInAMinute * 0.5, 17)
{
    
}

void SundialHintMessage1::RunMessage(LiquidCrystalShiftRegister& LCD, MP3& mp3)
{
    if(printing_is_in_progress)
    {
        if(!page_1_has_printed)
        {
            Serial.println(F("SundialHintMessage1Page1"));
            
            if(audio_file_number != -1)
            {
                mp3.Play(audio_file_number);
            }

            LCD.clear();
            LCD.setCursor(0,0); //line 1
            LCD.print(F("This will be the"));
            LCD.setCursor(0,1); //line 2
            LCD.print(F("hint given for"));

            SetTimeOfStartText(TheTime.GetTimeSinceEscapeRoomStartedInMilliseconds());
            page_1_has_printed = true;
        }
        else if(!page_2_has_printed && ItIsTimeToMoveToTheNextLine(1500))
        {
            Serial.println(F("SundialHintMessage1Page2"));
            
            LCD.clear();
            LCD.setCursor(0,0); //line 1
            LCD.print(F("the Sundial"));
            LCD.setCursor(0,1); //line 2
            LCD.print(F("Puzzle. :-)"));

            page_2_has_printed = true;
        }
        else if(page_2_has_printed && ItIsTimeToMoveToTheNextLine(3000))
        {
            Serial.println(F("SundialHintMessage1Finished"));
            
            printing_is_in_progress = false;

            time_to_share_message = -1; //Max int
        }
    }
}

void SundialHintMessage1::ResetPrintingPages()
{
    page_1_has_printed = false;
    page_2_has_printed = false;
}

TrojanMessage1::TrojanMessage1()
:MessageToCommunicator(TrojanMessage1Name, 0, 15)
{

}

void TrojanMessage1::RunMessage(LiquidCrystalShiftRegister& LCD, MP3& mp3)
{
    if(printing_is_in_progress)
    {
        if(!page_1_has_printed)
        {
            Serial.println(F("TrojanMessage1Page1"));

            if(audio_file_number != -1)
            {
                mp3.Play(audio_file_number);
            }

            LCD.clear();
            LCD.setCursor(0,0); //line 1
            LCD.print(F("Congrats! Okay."));
            LCD.setCursor(0,1); //line 2
            LCD.print(F("See that maze?"));

            SetTimeOfStartText(TheTime.GetTimeSinceEscapeRoomStartedInMilliseconds());
            page_1_has_printed = true;
        }
        else if(!page_2_has_printed && ItIsTimeToMoveToTheNextLine(2000))
        {
            Serial.println(F("TrojanMessage1Page2"));
            
            LCD.clear();
            LCD.setCursor(0,0); //line 1
            LCD.print(F("Use the pulleys"));
            LCD.setCursor(0,1); //line 2
            LCD.print(F("to get the"));

            page_2_has_printed = true;
        }
        else if(page_2_has_printed && !page_3_has_printed && ItIsTimeToMoveToTheNextLine(4000))
        {
            Serial.println(F("TrojanMessage1Page3"));
            
            LCD.clear();
            LCD.setCursor(0,0); //line 1
            LCD.print(F("Trojan Horse out"));
            LCD.setCursor(0,1); //line 2
            LCD.print(F("to discover a"));

            page_3_has_printed = true;
        }
        else if(page_3_has_printed && !page_4_has_printed && ItIsTimeToMoveToTheNextLine(5500))
        {
            Serial.println(F("TrojanMessage1Page4"));
            
            LCD.clear();
            LCD.setCursor(0,0); //line 1
            LCD.print(F("prophecy. Then,"));
            LCD.setCursor(0,1); //line 2
            LCD.print(F("use the symbols"));

            page_4_has_printed = true;
        }
        else if(page_4_has_printed && !page_5_has_printed && ItIsTimeToMoveToTheNextLine(7000))
        {
            Serial.println(F("TrojanMessage1Page4"));
            
            LCD.clear();
            LCD.setCursor(0,0); //line 1
            LCD.print(F("on the white"));
            LCD.setCursor(0,1); //line 2
            LCD.print(F("board to find"));

            page_5_has_printed = true;
        }
        else if(page_5_has_printed && !page_6_has_printed && ItIsTimeToMoveToTheNextLine(8000))
        {
            Serial.println(F("TrojanMessage1Page5"));
            
            LCD.clear();
            LCD.setCursor(0,0); //line 1
            LCD.print(F("the next code."));
            LCD.setCursor(0,1); //line 2
            LCD.print(F("Is the code:"));

            page_6_has_printed = true;
        }
        else if(page_6_has_printed && !page_7_has_printed && ItIsTimeToMoveToTheNextLine(10500))
        {
            Serial.println(F("TrojanMessage1Page6"));
            
            LCD.clear();
            LCD.setCursor(0,0); //line 1
            LCD.print(F("1. Clock"));
            LCD.setCursor(0,1); //line 2
            LCD.print(F("2. Lion"));

            page_7_has_printed = true;
        }
        else if(page_7_has_printed && !page_8_has_printed && ItIsTimeToMoveToTheNextLine(13000))
        {
            Serial.println(F("TrojanMessage1Page6"));
            
            LCD.clear();
            LCD.setCursor(0,0); //line 1
            LCD.print(F("3. Column"));
            LCD.setCursor(0,1); //line 2
            LCD.print(F("4. Closet"));

            page_8_has_printed = true;
        }
        else if(page_8_has_printed && !page_9_has_printed && ItIsTimeToMoveToTheNextLine(15500))
        {
            Serial.println(F("TrojanMessage1Page6"));
            
            LCD.clear();
            LCD.setCursor(0,0); //line 1
            LCD.print(F("5. Stone"));
            LCD.setCursor(0,1); //line 2
            LCD.print(F("6. Light"));

            page_9_has_printed = true;
        }
        else if(page_9_has_printed && ItIsTimeToMoveToTheNextLine(18000))
        {
            Serial.println(F("TrojanMessage1Finished"));
            
            printing_is_in_progress = false;

            time_to_share_message = -1; //Max int
        }
    }
}

void TrojanMessage1::ResetPrintingPages()
{
    page_1_has_printed = false;
    page_2_has_printed = false;
    page_3_has_printed = false;
    page_4_has_printed = false;
    page_5_has_printed = false;
    page_6_has_printed = false;
    page_7_has_printed = false;
    page_8_has_printed = false;
    page_9_has_printed = false;
}

TrojanHintMessage1::TrojanHintMessage1()
:MessageToCommunicator(TestHintMessage1Name, MillisecondsInAMinute * 3, 18)
{
    
}

void TrojanHintMessage1::RunMessage(LiquidCrystalShiftRegister& LCD, MP3& mp3)
{
    if(printing_is_in_progress)
    {
        if(!page_1_has_printed)
        {
            Serial.println(F("TrojanHintMessage1Page1"));
            
            if(audio_file_number != -1)
            {
                mp3.Play(audio_file_number);
            }

            LCD.clear();
            LCD.setCursor(0,0); //line 1
            LCD.print(F("This will be the"));
            LCD.setCursor(0,1); //line 2
            LCD.print(F("hint given for"));

            SetTimeOfStartText(TheTime.GetTimeSinceEscapeRoomStartedInMilliseconds());
            page_1_has_printed = true;
        }
        else if(!page_2_has_printed && ItIsTimeToMoveToTheNextLine(2000))
        {
            Serial.println(F("TrojanHintMessage1Page2"));
            
            LCD.clear();
            LCD.setCursor(0,0); //line 1
            LCD.print(F("the Trojan Horse"));
            LCD.setCursor(0,1); //line 2
            LCD.print(F("and Logic Puzzles."));

            page_2_has_printed = true;
        }
        else if(page_2_has_printed && ItIsTimeToMoveToTheNextLine(4000))
        {
            Serial.println(F("TrojanHintMessage1Finished"));
            
            printing_is_in_progress = false;

            time_to_share_message = -1; //Max int
        }
    }
}

void TrojanHintMessage1::ResetPrintingPages()
{
    page_1_has_printed = false;
    page_2_has_printed = false;
}

SlidingBlocksMessage1::SlidingBlocksMessage1()
:MessageToCommunicator(TestMessage1Name, 0, 19)
{

}

void SlidingBlocksMessage1::RunMessage(LiquidCrystalShiftRegister& LCD, MP3& mp3)
{
    if(printing_is_in_progress)
    {
        if(!page_1_has_printed)
        {
            Serial.println(F("SlidingBlocksMessage1Page1"));

            if(audio_file_number != -1)
            {
                mp3.Play(audio_file_number);
            }

            LCD.clear();
            LCD.setCursor(0,0); //line 1
            LCD.print(F("This will be"));
            LCD.setCursor(0,1); //line 2
            LCD.print(F("the message for"));

            SetTimeOfStartText(TheTime.GetTimeSinceEscapeRoomStartedInMilliseconds());
            page_1_has_printed = true;
        }
        else if(!page_2_has_printed && ItIsTimeToMoveToTheNextLine(1500))
        {
            Serial.println(F("SlidingBlocksMessage1Page2"));
            
            LCD.clear();
            LCD.setCursor(0,0); //line 1
            LCD.print(F("the Sliding"));
            LCD.setCursor(0,1); //line 2
            LCD.print(F("Blocks Puzzle."));

            page_2_has_printed = true;
        }
        else if(page_2_has_printed && ItIsTimeToMoveToTheNextLine(3000))
        {
            Serial.println(F("SlidingBlocksMessage1Finished"));
            
            printing_is_in_progress = false;

            time_to_share_message = -1; //Max int
        }
    }
}

void SlidingBlocksMessage1::ResetPrintingPages()
{
    page_1_has_printed = false;
    page_2_has_printed = false;
}

SlidingBlocksHintMessage1::SlidingBlocksHintMessage1()
:MessageToCommunicator(TestHintMessage1Name, MillisecondsInAMinute * 0.5, 20)
{
    
}

void SlidingBlocksHintMessage1::RunMessage(LiquidCrystalShiftRegister& LCD, MP3& mp3)
{
    if(printing_is_in_progress)
    {
        if(!page_1_has_printed)
        {
            Serial.println(F("SlidingBlocksHintMessage1Page1"));
            
            if(audio_file_number != -1)
            {
                mp3.Play(audio_file_number);
            }

            LCD.clear();
            LCD.setCursor(0,0); //line 1
            LCD.print(F("This will be the"));
            LCD.setCursor(0,1); //line 2
            LCD.print(F("hint given for"));

            SetTimeOfStartText(TheTime.GetTimeSinceEscapeRoomStartedInMilliseconds());
            page_1_has_printed = true;
        }
        else if(!page_2_has_printed && ItIsTimeToMoveToTheNextLine(2000))
        {
            Serial.println(F("SlidingBlocksHintMessage1Page2"));
            
            LCD.clear();
            LCD.setCursor(0,0); //line 1
            LCD.print(F("the Sliding"));
            LCD.setCursor(0,1); //line 2
            LCD.print(F("Blocks Puzzle."));

            page_2_has_printed = true;
        }
        else if(page_2_has_printed && ItIsTimeToMoveToTheNextLine(4000))
        {
            Serial.println(F("SlidingBlocksHintMessage1Finished"));
            
            printing_is_in_progress = false;

            time_to_share_message = -1; //Max int
        }
    }
}

void SlidingBlocksHintMessage1::ResetPrintingPages()
{
    page_1_has_printed = false;
    page_2_has_printed = false;
}

FinalEscapeMessage1::FinalEscapeMessage1()
:MessageToCommunicator(TestMessage1Name, 0, 21)
{

}

void FinalEscapeMessage1::RunMessage(LiquidCrystalShiftRegister& LCD, MP3& mp3)
{
    if(printing_is_in_progress)
    {
        if(!page_1_has_printed)
        {
            Serial.println(F("FinalEscapeMessage1Page1"));

            if(audio_file_number != -1)
            {
                mp3.Play(audio_file_number);
            }

            LCD.clear();
            LCD.setCursor(0,0); //line 1
            LCD.print(F("This will be"));
            LCD.setCursor(0,1); //line 2
            LCD.print(F("the message for"));

            SetTimeOfStartText(TheTime.GetTimeSinceEscapeRoomStartedInMilliseconds());
            page_1_has_printed = true;
        }
        else if(!page_2_has_printed && ItIsTimeToMoveToTheNextLine(2000))
        {
            Serial.println(F("FinalEscapeMessage1Page2"));
            
            LCD.clear();
            LCD.setCursor(0,0); //line 1
            LCD.print(F("the Final Escape"));
            LCD.setCursor(0,1); //line 2
            LCD.print(F("from the Room!!!"));

            page_2_has_printed = true;
        }
        else if(page_2_has_printed && ItIsTimeToMoveToTheNextLine(4000))
        {
            Serial.println(F("FinalEscapeMessage1Finished"));
            
            printing_is_in_progress = false;

            time_to_share_message = -1; //Max int
        }
    }
}

void FinalEscapeMessage1::ResetPrintingPages()
{
    page_1_has_printed = false;
    page_2_has_printed = false;
}

FinalEscapeHintMessage1::FinalEscapeHintMessage1()
:MessageToCommunicator(TestHintMessage1Name, MillisecondsInAMinute * 0.5, 22)
{
    
}

void FinalEscapeHintMessage1::RunMessage(LiquidCrystalShiftRegister& LCD, MP3& mp3)
{
    if(printing_is_in_progress)
    {
        if(!page_1_has_printed)
        {
            Serial.println(F("FinalEscapeHintMessage1Page1"));
            
            if(audio_file_number != -1)
            {
                mp3.Play(audio_file_number);
            }

            LCD.clear();
            LCD.setCursor(0,0); //line 1
            LCD.print(F("This will be the"));
            LCD.setCursor(0,1); //line 2
            LCD.print(F("hint given for"));

            SetTimeOfStartText(TheTime.GetTimeSinceEscapeRoomStartedInMilliseconds());
            page_1_has_printed = true;
        }
        else if(!page_2_has_printed && ItIsTimeToMoveToTheNextLine(2000))
        {
            Serial.println(F("FinalEscapeHintMessage1Page2"));
            
            LCD.clear();
            LCD.setCursor(0,0); //line 1
            LCD.print(F("the Final"));
            LCD.setCursor(0,1); //line 2
            LCD.print(F("Escape. :-)"));

            page_2_has_printed = true;
        }
        else if(page_2_has_printed && ItIsTimeToMoveToTheNextLine(4000))
        {
            Serial.println(F("FinalEscapeHintMessage1Finished"));
            
            printing_is_in_progress = false;

            time_to_share_message = -1; //Max int
        }
    }
}

void FinalEscapeHintMessage1::ResetPrintingPages()
{
    page_1_has_printed = false;
    page_2_has_printed = false;
}

bool Communicator::GetMayEnterPasscode()
{
    return may_enter_passcode;
}
    
void Communicator::SetMayEnterPasscode(bool val)
{
    may_enter_passcode = val;
}

void Communicator::SetPrintToStart()
{
    time_passcode_was_printed_to_screen = TheTime.GetTimeSinceEscapeRoomStartedInMilliseconds();
    passcode_printing = true;
}

bool Communicator::GetShouldWait()
{
    if(passcode_printing)
    {
        if(TheTime.GetTimeSinceEscapeRoomStartedInMilliseconds() - time_passcode_was_printed_to_screen > 2000)
        {
            return false;
        }
        else
        {
            return true;
        }
    }
    else
    {
        return false;
    } 
}

Communicator::Communicator()
:LCD(LCDLatchPort)
{
    LCD.begin(16, 2); //Set the LCD's number of columns and rows.
}

void Communicator::DisplayTimeRemainingToEscape()
{
    unsigned long seconds = TheTime.GetTimeLeftInEscapeRoomInMilliseconds() / 1000;
    float minutes = seconds / 60.0;
    int minutes_on_display = minutes;
    float seconds_in_remainder = (minutes - minutes_on_display) * 60;
    int seconds_on_display = seconds_in_remainder;

    if(seconds_on_display != previous_seconds_on_display)
    { 
        LCD.clear();
        LCD.setCursor(0,0); //1st line
        LCD.print(F("Time Left: "));
        LCD.setCursor(0,1); //2nd line
        LCD.print(minutes_on_display);
        LCD.print(F(":"));
        LCD.print(seconds_on_display);
        previous_seconds_on_display = seconds_on_display;
    }
}

void Communicator::SayNumberEntered(int number_entered)
{
    switch (number_entered)
    {
        case 0:
            mp3.Play(3);
            break;
        case 1:
            mp3.Play(4);
            break;
        case 2:
            mp3.Play(5);
            break;
        case 3:
            mp3.Play(6);
            break;
        case 4:
            mp3.Play(7);
            break;
        case 5:
            mp3.Play(8);
            break;
        case 6:
            mp3.Play(9);
            break;
        case 7:
            mp3.Play(10);
            break;
        case 8:
            mp3.Play(11);
            break;
        case 9:
            mp3.Play(12);
            break;
    }
}


bool Communicator::RunCommunicator(unsigned long time_when_started_task)
{
    int keypad_input = keypad.Run();
    bool communicator_output = false;

    mp3.AdjustVolumeAsRequested();

    if(CommunicatorMessageShouldRun(time_when_started_task)) //keypad.Run() checks the ReplayLastMessageButton
    {
        CheckAndRunMessages(time_when_started_task, false);
    }
    else if (keypad_input == 10)
    {
        Serial.println(F("keypad.Run() == 10 was true"));
        CheckAndRunMessages(time_when_started_task, true);
    }
    else if (!(keypad_input == 10 || keypad_input == -1) && GetMayEnterPasscode())
    {
        SayNumberEntered(keypad_input);
        communicator_output = RunPasscodeReader(keypad_input);
    }
    else if (GetShouldWait())
    {
        //do nothing
    }
    else
    {
        DisplayTimeRemainingToEscape();
    }

    return communicator_output;
}

SundialCommunicator::SundialCommunicator()
{
    LastMessagePtr = &test_message_1;
}

bool SundialCommunicator::CommunicatorMessageShouldRun(unsigned long time_when_started_task)
{
    return test_message_1.ItIsTimeToShareMessage(time_when_started_task) || 
            test_hint_message_1.ItIsTimeToShareMessage(time_when_started_task) ||
            test_message_1.PrintingIsInProgress() ||
            test_hint_message_1.PrintingIsInProgress();
}

void SundialCommunicator::CheckAndRunMessages(unsigned long time_when_started_task, bool repeat_button_was_pressed)
{
    if(!test_message_1.PrintingIsInProgress() && 
            test_message_1.ItIsTimeToShareMessage(time_when_started_task))
    {
        test_message_1.SetPrintingIsInProgress(true);
    }
    if(!test_hint_message_1.PrintingIsInProgress() && 
            test_hint_message_1.ItIsTimeToShareMessage(time_when_started_task))
    {
        test_hint_message_1.SetPrintingIsInProgress(true);
        LastMessagePtr = &test_hint_message_1;
    }
    if(!test_message_1.PrintingIsInProgress() && !test_hint_message_1.PrintingIsInProgress() 
        && repeat_button_was_pressed)
    {
        LastMessagePtr->SetPrintingIsInProgress(true);
        LastMessagePtr->ResetPrintingPages();
    }

    test_message_1.RunMessage(LCD, mp3);
    test_hint_message_1.RunMessage(LCD, mp3);
}

bool SundialCommunicator::RunPasscodeReader(int keypad_input)
{
    current_passcode_attempt[ current_passcode_digit ] = keypad_input;

    LCD.clear();
    LCD.setCursor(0,0); //1st line
    LCD.print(current_passcode_attempt[0]);
    LCD.print(current_passcode_attempt[1]);   
    LCD.print(F(":"));
    LCD.print(current_passcode_attempt[2]);
    LCD.print(current_passcode_attempt[3]);
    SetPrintToStart();

    current_passcode_digit++;
    if(current_passcode_digit > 3)
    {
        current_passcode_digit = 0;

        LCD.setCursor(0,1); //2nd line
        if(current_passcode_attempt[0] == PasscodeDigit1 && current_passcode_attempt[1] == PasscodeDigit2 
            && current_passcode_attempt[2] == PasscodeDigit3 && current_passcode_attempt[3] == PasscodeDigit4)
        {
            mp3.Play(14);
            LCD.print(F("Correct! :-)"));
            return true;
        }
        else
        {
            mp3.Play(13);
            LCD.print(F("Incorrect! :-("));
        }
    }

    return false;
}

TrojanAndLogicCommunicator::TrojanAndLogicCommunicator()
{
    LastMessagePtr = &trojan_message_1;
}

bool TrojanAndLogicCommunicator::CommunicatorMessageShouldRun(unsigned long time_when_started_task)
{
    return trojan_message_1.ItIsTimeToShareMessage(time_when_started_task) || 
            test_hint_message_1.ItIsTimeToShareMessage(time_when_started_task) ||
            trojan_message_1.PrintingIsInProgress() ||
            test_hint_message_1.PrintingIsInProgress();
}

void TrojanAndLogicCommunicator::CheckAndRunMessages(unsigned long time_when_started_task, bool repeat_button_was_pressed)
{
    if(!trojan_message_1.PrintingIsInProgress() && 
            trojan_message_1.ItIsTimeToShareMessage(time_when_started_task))
    {
        trojan_message_1.SetPrintingIsInProgress(true);
    }
    if(!test_hint_message_1.PrintingIsInProgress() && 
            test_hint_message_1.ItIsTimeToShareMessage(time_when_started_task))
    {
        test_hint_message_1.SetPrintingIsInProgress(true);
        LastMessagePtr = &test_hint_message_1;
    }
    if(!trojan_message_1.PrintingIsInProgress() && !test_hint_message_1.PrintingIsInProgress() 
        && repeat_button_was_pressed)
    {
        LastMessagePtr->SetPrintingIsInProgress(true);
        LastMessagePtr->ResetPrintingPages();
    }

    trojan_message_1.RunMessage(LCD, mp3);
    test_hint_message_1.RunMessage(LCD, mp3);
}

bool TrojanAndLogicCommunicator::RunPasscodeReader(int keypad_input)
{
    current_passcode_attempt = keypad_input;

    LCD.clear();
    LCD.setCursor(0,0); //1st line
    LCD.print(current_passcode_attempt);
    LCD.print(F(": "));
    SetPrintToStart();
    if(current_passcode_attempt == 4)
    {
        mp3.Play(14);
        LCD.print(F("Correct!"));
        return true;
    }
    else
    {
        mp3.Play(13);
        LCD.print(F("Incorrect."));
        return false;
    }
}

SlidingBlocksCommunicator::SlidingBlocksCommunicator()
{
    LastMessagePtr = &test_message_1;
    SetMayEnterPasscode(false);
}

bool SlidingBlocksCommunicator::CommunicatorMessageShouldRun(unsigned long time_when_started_task)
{
    return test_message_1.ItIsTimeToShareMessage(time_when_started_task) || 
            test_hint_message_1.ItIsTimeToShareMessage(time_when_started_task) ||
            test_message_1.PrintingIsInProgress() ||
            test_hint_message_1.PrintingIsInProgress();
}

void SlidingBlocksCommunicator::CheckAndRunMessages(unsigned long time_when_started_task, bool repeat_button_was_pressed)
{
    if(!test_message_1.PrintingIsInProgress() && 
            test_message_1.ItIsTimeToShareMessage(time_when_started_task))
    {
        test_message_1.SetPrintingIsInProgress(true);
    }
    if(!test_hint_message_1.PrintingIsInProgress() && 
            test_hint_message_1.ItIsTimeToShareMessage(time_when_started_task))
    {
        test_hint_message_1.SetPrintingIsInProgress(true);
        LastMessagePtr = &test_hint_message_1;
    }
    if(!test_message_1.PrintingIsInProgress() && !test_hint_message_1.PrintingIsInProgress() 
        && repeat_button_was_pressed)
    {
        LastMessagePtr->SetPrintingIsInProgress(true);
        LastMessagePtr->ResetPrintingPages();
    }

    test_message_1.RunMessage(LCD, mp3);
    test_hint_message_1.RunMessage(LCD, mp3);
}

bool SlidingBlocksCommunicator::RunPasscodeReader(int keypad_input)
{
    //Does nothing
}

FinalEscapeCommunicator::FinalEscapeCommunicator()
{
    LastMessagePtr = &test_message_1;
    SetMayEnterPasscode(false);
}

bool FinalEscapeCommunicator::CommunicatorMessageShouldRun(unsigned long time_when_started_task)
{
    return test_message_1.ItIsTimeToShareMessage(time_when_started_task) || 
            test_hint_message_1.ItIsTimeToShareMessage(time_when_started_task) ||
            test_message_1.PrintingIsInProgress() ||
            test_hint_message_1.PrintingIsInProgress();
}

void FinalEscapeCommunicator::CheckAndRunMessages(unsigned long time_when_started_task, bool repeat_button_was_pressed)
{
    if(!test_message_1.PrintingIsInProgress() && 
            test_message_1.ItIsTimeToShareMessage(time_when_started_task))
    {
        test_message_1.SetPrintingIsInProgress(true);
    }
    if(!test_hint_message_1.PrintingIsInProgress() && 
            test_hint_message_1.ItIsTimeToShareMessage(time_when_started_task))
    {
        test_hint_message_1.SetPrintingIsInProgress(true);
        LastMessagePtr = &test_hint_message_1;
    }
    if(!test_message_1.PrintingIsInProgress() && !test_hint_message_1.PrintingIsInProgress() 
        && repeat_button_was_pressed)
    {
        LastMessagePtr->SetPrintingIsInProgress(true);
        LastMessagePtr->ResetPrintingPages();
    }

    test_message_1.RunMessage(LCD, mp3);
    test_hint_message_1.RunMessage(LCD, mp3);
}

bool FinalEscapeCommunicator::RunPasscodeReader(int keypad_input)
{
    //Does nothing
}