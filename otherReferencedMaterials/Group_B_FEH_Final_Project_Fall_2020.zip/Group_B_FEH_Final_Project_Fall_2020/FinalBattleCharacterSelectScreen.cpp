#include "FinalBattleCharacterSelectScreen.h"

FinalBattleCharacterSelectScreen::FinalBattleCharacterSelectScreen()
:ChooseCharacter("Choose Your Character", MAX_X/2+20, CHAR_HEIGHT/2 + 4, MAX_X, CHAR_HEIGHT, LCD.Black),
 BrookeButton("Brooke (Good Luck Cat - Extra Attack)", MAX_X/2, 50, MAX_X, 30, LCD.Black, LCD.Black, LCD.White, LCD.Gray),
 ErinButton("Erin (Peanut Butter Oatmeal - Extra Debuff)", MAX_X/2, 90, MAX_X, 30, LCD.Black, LCD.Black, LCD.White, LCD.Gray),
 JimmyButton("Jimmy (Eggo Waffle - Heal Multiplier)", MAX_X/2, 130, MAX_X, 30, LCD.Black, LCD.Black, LCD.White, LCD.Gray),
 KyleButton("Kyle (Teleportation - Increase Dodge Rate)", MAX_X/2, 170, MAX_X, 30, LCD.Black, LCD.Black, LCD.White, LCD.Gray),
 RileyButton("Riley (Hot Coffee - Extra Buff)", MAX_X/2, 210, MAX_X, 30, LCD.Black, LCD.Black, LCD.White, LCD.Gray),
 X("X", MAX_X - CHAR_WIDTH, 4, CHAR_WIDTH, CHAR_HEIGHT, LCD.Black, LCD.Red, LCD.Red)
{

}

void FinalBattleCharacterSelectScreen::DrawScreen()
{
    LCD.Clear(LCD.Red);

    BrookeButton.SetEnabled(false);
    ErinButton.SetEnabled(false);
    JimmyButton.SetEnabled(false);
    KyleButton.SetEnabled(false);
    RileyButton.SetEnabled(false);

    Stats& stats = Stats::Instance();

    if(stats.GetCurrentPlayerStats().spot_speed_points >= 1 && stats.GetCurrentPlayerStats().aerodynamics_points >= 1)
        ErinButton.SetEnabled(true);

    if(stats.GetCurrentPlayerStats().spot_speed_points >= 2 && stats.GetCurrentPlayerStats().aerodynamics_points >= 2)
        KyleButton.SetEnabled(true);

    if(stats.GetCurrentPlayerStats().spot_speed_points >= 3 && stats.GetCurrentPlayerStats().aerodynamics_points >= 3)
        JimmyButton.SetEnabled(true);

    if(stats.GetCurrentPlayerStats().spot_speed_points >= 4 && stats.GetCurrentPlayerStats().aerodynamics_points >= 4)
        RileyButton.SetEnabled(true);

    if(stats.GetCurrentPlayerStats().spot_speed_points >= 5 && stats.GetCurrentPlayerStats().aerodynamics_points >= 5)
        BrookeButton.SetEnabled(true);
    
    ChooseCharacter.Draw();
    BrookeButton.Draw();
    ErinButton.Draw();
    JimmyButton.Draw();
    KyleButton.Draw();
    RileyButton.Draw();
    X.Draw();
}

void FinalBattleCharacterSelectScreen::ScreenTouched(int x, int y)
{
   if(X.WasControlTouched(x,y))
   {
       ShouldExitScreen = true;
   }
   else if(BrookeButton.WasControlTouched(x,y))
   {
       final_battle_go.SetCharacterName(FinalBattleCharacter::Brooke);
       final_battle_go.StartScreen();
   }
   else if(ErinButton.WasControlTouched(x,y))
   {
       final_battle_go.SetCharacterName(FinalBattleCharacter::Erin);
       final_battle_go.StartScreen();
   }
   else if(JimmyButton.WasControlTouched(x,y))
   {
       final_battle_go.SetCharacterName(FinalBattleCharacter::Jimmy);
       final_battle_go.StartScreen();
   }
   else if(KyleButton.WasControlTouched(x,y))
   {
       final_battle_go.SetCharacterName(FinalBattleCharacter::Kyle);
       final_battle_go.StartScreen();
   }
   else if(RileyButton.WasControlTouched(x,y))
   {
       final_battle_go.SetCharacterName(FinalBattleCharacter::Riley);
       final_battle_go.StartScreen();
   }
}