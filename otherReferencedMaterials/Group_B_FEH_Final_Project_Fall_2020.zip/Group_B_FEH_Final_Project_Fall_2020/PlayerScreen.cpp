#include "PlayerScreen.h"

PlayerScreen::PlayerScreen()
:Title("Titles Are Hard", MAX_X/2+10, CHAR_HEIGHT/2 + 4, MAX_X, CHAR_HEIGHT, LCD.Black),
 Choose_Player("Choose Player", MAX_X/2, 40, MAX_X, CHAR_HEIGHT, LCD.Black),
 Arson("Arson", MAX_X/2, 90, 150, 30, LCD.Black, LCD.Black, LCD.White),
 Riot("Riot", MAX_X/2, 140, 150, 30, LCD.Black, LCD.Black, LCD.White),
 Tax_Fraud("Tax Fraud", MAX_X/2, 190, 150, 30, LCD.Black, LCD.Black, LCD.White)
{
    
}

void PlayerScreen::DrawScreen()
{
    LCD.Clear(LCD.Red);

    Title.Draw();
    Choose_Player.Draw();
    Arson.Draw();
    Riot.Draw();
    Tax_Fraud.Draw();
}

void PlayerScreen::ScreenTouched(int x, int y)
{
   if(Arson.WasControlTouched(x,y))
   {
       menu.StartScreen();
       Stats::Instance().current_player = PlayerStats::Arson;
   }
   else if(Riot.WasControlTouched(x,y))
   {
       menu.StartScreen();
       Stats::Instance().current_player = PlayerStats::Riot;
   }   
   else if(Tax_Fraud.WasControlTouched(x,y))
   {
       menu.StartScreen();
       Stats::Instance().current_player = PlayerStats::Tax_Fraud;
   }
}