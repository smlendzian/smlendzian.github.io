#ifndef CreditsScreen_h 
#define CreditsScreen_h 

#include "Screen.h"

//The CreditsScreen is drawn after the appropriate Button is clicked on the MenuScreen.
//The credits for the game are displayed here.
//The player can return to the MenuScreen.
class CreditsScreen : public Screen 
{
   private:
   TextBox Credits, Game_Developers, V_L_S, Helped_By, Help_Line_1, Help_Line_2, Help_Line_3, Approved_By_Drew_Phillips; 
   Button X;
   TeacupSprite Teacup;

   public:

   CreditsScreen();

   virtual void DrawScreen();
   virtual void ScreenTouched(int x, int y);
};

#endif