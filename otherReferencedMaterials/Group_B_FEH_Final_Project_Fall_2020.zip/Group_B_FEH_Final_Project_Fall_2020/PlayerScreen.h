#ifndef PlayerScreen_h 
#define PlayerScreen_h 

#include "Screen.h"
#include "MenuScreen.h"

//This Screen is the first the player will see.
//It allows the player to click on the player slot they want.
//The statistics for that player slot will be read in,
//and unless the player slot is changed, future changes in statistics will effect that file.
//After a Button is clicked, the MenuScreen will be brought up.
//(The PlayerScreen can also be accessed from the MenuScreen.)
class PlayerScreen : public Screen 
{
   private:
   TextBox Title, Choose_Player; 
   Button Arson, Riot, Tax_Fraud;
   MenuScreen menu;

   public:

   PlayerScreen();

   virtual void DrawScreen();
   virtual void ScreenTouched(int x, int y);
};

#endif