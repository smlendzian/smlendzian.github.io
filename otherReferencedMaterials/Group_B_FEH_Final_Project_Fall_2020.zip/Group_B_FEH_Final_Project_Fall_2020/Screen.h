#ifndef Screen_h 
#define Screen_h 

#include "FEHLCD.h"
#include "FEHRandom.h"
#include "FEHSD.h"
#include "FEHUtility.h"
#include "Controls.h"
#include "Sprites.h"
#include "FinalBattleClasses.h"
#include "Stats.h"

//A Screen includes everything that is drawn/visible and that can be interacted with on the screen of the game at a particular state/stage of the game.
class Screen
{
    protected:
    //Used to determine whether to return to a previous Screen
    bool ShouldExitScreen;
    bool first_draw;

    public:

    Screen();

    //Displays Screen.
    virtual void DrawScreen() = 0;

    //Starts/runs gameplay on screen.
    void StartScreen();

    //Used in each Screen to handle the effects of a particular point on a Screen being touched (different for each derived class of Screen)
    virtual void ScreenTouched(int x, int y) = 0;
};

#endif