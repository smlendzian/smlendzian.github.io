#include "Sundial.h"

//Name list for RAM conservation
const char PROGMEM SundialName[] = "Sundial";
const char PROGMEM SundialButton1Name[] = "SundialButton1";
const char PROGMEM SundialButton2Name[] = "SundialButton2";
const char PROGMEM SundialButton3Name[] = "SundialButton3";
const char PROGMEM SundialButton4Name[] = "SundialButton4";
const char PROGMEM SundialLED1Name[] = "SundialLED1";
const char PROGMEM SundialLED2Name[] = "SundialLED2";
const char PROGMEM SundialLED3Name[] = "SundialLED3";
const char PROGMEM SundialLED4Name[] = "SundialLED4";
const char PROGMEM MainRoomLightLEDName[] = "MainRoomLightLED";

Sundial::Sundial()
:Task(SundialName),
SundialButton1(SundialButton1Name, DigitalSensor::Mux1, SundialButton1Port),
SundialButton2(SundialButton2Name, DigitalSensor::Mux1, SundialButton2Port),
SundialButton3(SundialButton3Name, DigitalSensor::Mux1, SundialButton3Port),
SundialButton4(SundialButton4Name, DigitalSensor::Mux1, SundialButton4Port),
SundialLED1(SundialLED1Name, LED::LEDBank, SundialLED1Port),
SundialLED2(SundialLED2Name, LED::LEDBank, SundialLED2Port),
SundialLED3(SundialLED3Name, LED::LEDBank, SundialLED3Port),
SundialLED4(SundialLED4Name, LED::LEDBank, SundialLED4Port),
MainRoomLightLED(MainRoomLightLEDName, LED::LEDBank, MainRoomLightLEDPort)
{
    
}

void Sundial::Run()
{
    while(!ShouldEndTask) //Loop is redundant but used for clarity
    {
        bool password_success = sundial_communicator.RunCommunicator(Task::TimeWhenStartedTask);

        ToggleLEDWhenButtonClicked(SundialButton1, SundialLED1);
        ToggleLEDWhenButtonClicked(SundialButton2, SundialLED2);
        ToggleLEDWhenButtonClicked(SundialButton3, SundialLED3);
        ToggleLEDWhenButtonClicked(SundialButton4, SundialLED4);

        if(password_success) 
        {
            Serial.println(F("PasswordSuccess"));

            LEDBank::TurnOffAllLEDs();
            MainRoomLightLED.TurnOnLED();

            ShouldEndTask = true;   //Ends the loop in Task::Start() to return to the MainMenu
        }
    }
}

//Pass objects by reference to avoid making a copy.
void Sundial::ToggleLEDWhenButtonClicked(Button& button, LED& led)
{
    //Check whether the button was not pressed before but is pressed now.
    if(!button.ButtonWasPressed() && button.ButtonIsPressed())
    //Checks the previous reading variable, and then does a new reading
    //(changing that variable, so the order of this if statement is important)
    {
        Serial.print(button.Name());
        Serial.println(F("WasPressed"));
    }
    //Check whether the button was pressed before but is released now.
    else if(button.ButtonWasPressed() && button.ButtonIsReleased())
    {
        Serial.print(button.Name());
        Serial.println(F("WasReleased"));

        led.ToggleLED();
    }
}