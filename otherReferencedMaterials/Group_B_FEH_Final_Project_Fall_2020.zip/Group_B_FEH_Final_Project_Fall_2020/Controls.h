#ifndef Controls_h 
#define Controls_h

#include "FEHLCD.h"
#include "LCDColors.h"
#include "FEHUtility.h"
#include "FEHRandom.h"
#include "stdlib.h"
#include <string>  

#define MAX_X 320
#define MAX_Y 240
#define CHAR_HEIGHT 14 //This is an approximation.
#define CHAR_WIDTH 9 //This is an approximation.

//A Control is a rectangular region on the Screen.
class Control
{
   protected:
   //x_start and y_start represent the upper left corner of the Control. x and y are in the middle of the Control.
   int x=0, y=0, width=MAX_X, height=MAX_Y, x_start, y_start;

   public:
   //Creates Control with coordinates x and y in the middle of the Control with the specified width and height.
   Control(int x_val, int y_val, int w, int h);

   //All Controls must have a function that Draws the Control on the Screen.
   virtual void Draw() = 0;

   //Changes the location of the Control by assigning new values to x and y.
   void UpdateLocation(int x_new, int y_new);

   //Draws over the Control with a rectangle the color of the background.
   void UnDraw(int background_color);

   //Draws a box of the specified color around the Control. The added_width and added_height are the amount of pixels larger than the Control's width and height the box will be.
   void DrawBoxAround(int added_width, int added_height, int box_color);
};

//A TextBox is a type of Control that displays text.
class TextBox : public Control
{
    protected:
    std::string text;
    int len;

    int text_color;

    public:

    //Creates TextBox with coordinates x and y in the middle of the text (with the specified text color).
    TextBox(const char*text_val, int x_val, int y_val, int w, int h, int color);

    //Draws the Control on the Screen.
    virtual void Draw();

    void SetText(const char*text_val);

    void SetText(int int_val);
};

//A Button is a type of TextBox that draws a box around the text and has a boolean function for determining whether the Button was clicked.
class Button : public TextBox
{
    protected:

    int border_color, fill_color;

    public:

    //Creates TextBox with coordinates x and y in the middle of the text (with the specified text, border, and fill colors).
    Button(const char*text_val, int x_val, int y_val, int w, int h, int color_text, int color_border, int color_fill);

    //Draws the Control on the Screen.
    virtual void Draw();

    //Determines whether the Control was clicked (returns True if clicked and False if not)
    bool WasControlTouched(int x_val, int y_val);
};

//A ConditionalButton is a type of Button that changes color depending on a condition and only does anything when clicked if the condition is met.
class ConditionalButton : public Button
{
    protected:

    int true_color_fill, false_color_fill;
    bool is_enabled;

    public:

    //Creates ConditionalButton with coordinates x and y in the middle of the text (with the specified text, border, and fill colors for when the condition is met or not met).
    //The last argument is a boolean variable that must be true if the condition is met and false if it is not.
    ConditionalButton(const char*text_val, int x_val, int y_val, int w, int h, int color_text, int color_border, int color_fill_true, int color_fill_false);

    //Draws the Control on the Screen.
    virtual void Draw();

    void SetEnabled(bool is_enabled_val);

    //Determines whether the Control was clicked (returns True if clicked and enabled and False if not)
    bool WasControlTouched(int x_val, int y_val);
};

//The airplane is the shape that will have to stay in the box during the aerodynamics game
class airplane
{
    protected:

    
    float bigrx11,bigry11,bigrx12,bigry12,bigrx21,bigry21,bigrx22,bigry22,bigt1x,bigt2x,bigt3x,bigt4x,bigt5x,bigt6x,bigt1y,bigt2y,bigt3y,bigt4y,bigt5y,bigt6y,lilt1x,lilt1y,lilt2x,lilt2y,lilt3x,lilt3y,lilt4x,lilt4y;
    int bwidth,bheight,r;
    public:

    //creates an airplane with the given dimensions
    airplane(float abigrx11,float abigry11,float abigrx12,float abigry12,float abigrx21,float abigry21,float abigrx22,float abigry22,float abigt1x,float abigt2x,float abigt3x,float abigt4x,float abigt5x,float abigt6x,float abigt1y,float abigt2y,float abigt3y,float abigt4y,float abigt5y,float abigt6y,float alilt1x,float alilt1y,float alilt2x,float alilt2y,float alilt3x,float alilt3y,float alilt4x,float alilt4y, int ar,int abwidth, int abheight);

    //Draws the Control on the Screen.
     void Draw();
};
//The airplane is the shape that will have to stay in the box during the aerodynamics game
class airplaneoutline
{
    protected:

    
    float obigrx11,obigry11,obigrx12,obigry12,obigrx21,obigry21,obigrx22,obigry22,obigt1x,obigt2x,obigt3x,obigt4x,obigt5x,obigt6x,obigt1y,obigt2y,obigt3y,obigt4y,obigt5y,obigt6y,olilt1x,olilt1y,olilt2x,olilt2y,olilt3x,olilt3y,olilt4x,olilt4y;
    int obwidth,obheight,oor;
    public:

    //creates an airplane with the given dimensions
    airplaneoutline(float oabigrx11,float oabigry11,float oabigrx12,float oabigry12,float oabigrx21,float oabigry21,float oabigrx22,float oabigry22,float oabigt1x,float oabigt2x,float oabigt3x,float oabigt4x,float oabigt5x,float oabigt6x,float oabigt1y,float oabigt2y,float oabigt3y,float oabigt4y,float oabigt5y,float oabigt6y,float oalilt1x,float oalilt1y,float oalilt2x,float oalilt2y,float oalilt3x,float oalilt3y,float oalilt4x,float oalilt4y, int oar,int oabwidth, int oabheight);

    //Draws the Control on the Screen.
     void Draw();
};

//AirplaneErase is a rectangle of a special size to cover the airplane
class AirplaneErase
{
    protected:

    int x__start, y__start, width_erase, height_erase;

    public:

    //Creates A Rectangle with coordinates x and y and a certain color to erase an airplane
    AirplaneErase(int x__s,int y__s,int widtherase, int heighterase);

    //Draws the Control on the Screen.
    virtual void Draw();

};
//AirplaneSleep pauses the game for a bit of time
class Airplanesleep
{
    protected:

    float time_sleep;

    public:

    //Pauses the the screen for a certain amount of time
    Airplanesleep(float TimeSleep);

    void Draw();

};

#endif