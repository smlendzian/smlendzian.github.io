#ifndef SlidingBlocks_h
#define SlidingBlocks_h

#include "Task.h"

class SlidingBlocksButton : public Button
{
    protected:
    bool button_was_pressed_correctly = false; 
    //Holds the value of whether the button was pressed after the correct other buttons.

    public:
    SlidingBlocksButton(const char* PROGMEM name_val, PortLocation port_location_val, int port_num, long initial_state_val = RELEASED);

    bool GetButtonWasPressedCorrectly();
    void SetButtonWasPressedCorrectly(bool button_was_pressed_correctly_val);
    void CheckWhetherButtonWasClicked();
};

//SlidingBlocks is a type of Task that owns all of the Buttons and functions needed for the Sliding Blocks Puzzle.
class SlidingBlocks : public Task
{
    protected:
    SlidingBlocksCommunicator communicator;
    
    public:
    //8 buttons (3 x 3 grid with 1 space free for moving blocks)
    SlidingBlocksButton SlidingBlocksButton1;
    SlidingBlocksButton SlidingBlocksButton2;
    SlidingBlocksButton SlidingBlocksButton3;
    SlidingBlocksButton SlidingBlocksButton4;
    SlidingBlocksButton SlidingBlocksButton5;
    SlidingBlocksButton SlidingBlocksButton6;
    SlidingBlocksButton SlidingBlocksButton7;
    SlidingBlocksButton SlidingBlocksButton8;

    SlidingBlocks();

    virtual void Run();

    void SlidingBlocksSolved(); //Moves the Servo to open the door
};

#endif