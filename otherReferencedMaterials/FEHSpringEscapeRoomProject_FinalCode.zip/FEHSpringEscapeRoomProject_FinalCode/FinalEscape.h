#ifndef FinalEscape_h
#define FinalEscape_h

#include "Task.h" 

//FinalEscape is a Task for the final escape from the room
//(created to handle the communicator messages for this final stage)
class FinalEscape : public Task
{
    Button StartTestButton;
    
    public:

    FinalEscapeCommunicator communicator;

    FinalEscape();

    virtual void Run();
};

#endif