#ifndef MessagesToCommunicator_h
#define MessagesToCommunicator_h

#include <SPI.h>
#include <LiquidCrystalShiftRegister.h>
//I am using a library downloaded from https://www.instructables.com/LCD-Screen-With-74HC595-and-Keypad-Module/
//to be able to use the LCD Screen with a Shift Register
//in order to decrease the number of pins on the Arduino needed.
#include "Devices.h"
#include "MP3.h"
#include "Keypad.h"

#define PasscodeDigit1 1
#define PasscodeDigit2 1
#define PasscodeDigit3 0
#define PasscodeDigit4 0

class MessageToCommunicator
{
    protected:
    const char* PROGMEM name;
    unsigned long time_to_share_message; //Time between the start of the Task and when to share the message (ms)
    unsigned long time_of_start_text = 0;
    bool printing_is_in_progress = false;
    int audio_file_number;
    
    public:
    MessageToCommunicator(const char* PROGMEM name_val, unsigned long time_to_share_message_val = 0, int audio_file_num_val = -1);

    virtual void RunMessage(LiquidCrystalShiftRegister& LCD, MP3& mp3) = 0;

    bool ItIsTimeToShareMessage(unsigned long time_since_task_started_val);

    void SetTimeOfStartText(unsigned long time_of_start_text_val);
    bool ItIsTimeToMoveToTheNextLine(unsigned long scroll_delay_in_milliseconds);

    bool PrintingIsInProgress();
    void SetPrintingIsInProgress(bool printing_is_in_progress_val);

    virtual void ResetPrintingPages() = 0;
};

/*class TestMessage1 : public MessageToCommunicator
{
    bool page_1_has_printed = false, page_2_has_printed = false, page_3_has_printed = false;
    
    public:  
    TestMessage1();
    virtual void RunMessage(LiquidCrystalShiftRegister& LCD, MP3& mp3);
    virtual void ResetPrintingPages();
};

class TestHintMessage1 : public MessageToCommunicator
{
    bool page_1_has_printed = false, page_2_has_printed = false, page_3_has_printed = false;
    
    public:  
    TestHintMessage1();
    virtual void RunMessage(LiquidCrystalShiftRegister& LCD, MP3& mp3);
    virtual void ResetPrintingPages();
};*/

class SundialMessage1 : public MessageToCommunicator
{
    bool page_1_has_printed = false, page_2_has_printed = false;
    
    public:  
    SundialMessage1();
    virtual void RunMessage(LiquidCrystalShiftRegister& LCD, MP3& mp3);
    virtual void ResetPrintingPages();
};

class SundialHintMessage1 : public MessageToCommunicator
{
    bool page_1_has_printed = false, page_2_has_printed = false;
    
    public:  
    SundialHintMessage1();
    virtual void RunMessage(LiquidCrystalShiftRegister& LCD, MP3& mp3);
    virtual void ResetPrintingPages();
};

class TrojanMessage1 : public MessageToCommunicator
{
    bool page_1_has_printed = false, page_2_has_printed = false, page_3_has_printed = false, page_4_has_printed = false,
        page_5_has_printed = false, page_6_has_printed = false, page_7_has_printed = false, page_8_has_printed = false, page_9_has_printed = false;
    
    public:  
    TrojanMessage1();
    virtual void RunMessage(LiquidCrystalShiftRegister& LCD, MP3& mp3);
    virtual void ResetPrintingPages();
};

class TrojanHintMessage1 : public MessageToCommunicator
{
    bool page_1_has_printed = false, page_2_has_printed = false;
    
    public:  
    TrojanHintMessage1();
    virtual void RunMessage(LiquidCrystalShiftRegister& LCD, MP3& mp3);
    virtual void ResetPrintingPages();
};

class SlidingBlocksMessage1 : public MessageToCommunicator
{
    bool page_1_has_printed = false, page_2_has_printed = false;
    
    public:  
    SlidingBlocksMessage1();
    virtual void RunMessage(LiquidCrystalShiftRegister& LCD, MP3& mp3);
    virtual void ResetPrintingPages();
};

class SlidingBlocksHintMessage1 : public MessageToCommunicator
{
    bool page_1_has_printed = false, page_2_has_printed = false;
    
    public:  
    SlidingBlocksHintMessage1();
    virtual void RunMessage(LiquidCrystalShiftRegister& LCD, MP3& mp3);
    virtual void ResetPrintingPages();
};

class FinalEscapeMessage1 : public MessageToCommunicator
{
    bool page_1_has_printed = false, page_2_has_printed = false;
    
    public:  
    FinalEscapeMessage1();
    virtual void RunMessage(LiquidCrystalShiftRegister& LCD, MP3& mp3);
    virtual void ResetPrintingPages();
};

class FinalEscapeHintMessage1 : public MessageToCommunicator
{
    bool page_1_has_printed = false, page_2_has_printed = false;
    
    public:  
    FinalEscapeHintMessage1();
    virtual void RunMessage(LiquidCrystalShiftRegister& LCD, MP3& mp3);
    virtual void ResetPrintingPages();
};

class Communicator
{
    protected:
    LiquidCrystalShiftRegister LCD;
    MP3 mp3;
    Keypad keypad;

    int previous_seconds_on_display;
    MessageToCommunicator* LastMessagePtr = 0;

    bool may_enter_passcode = true;
    int current_passcode_digit = 0;
    unsigned long time_passcode_was_printed_to_screen;
    bool passcode_printing = false;

    public:
    
    Communicator();

    bool RunCommunicator(unsigned long time_when_started_task);

    void DisplayTimeRemainingToEscape();

    //Checks whether to run messages and runs them accordingly
    virtual void CheckAndRunMessages(unsigned long time_when_started_task, bool repeat_button_was_pressed) = 0;

    virtual bool CommunicatorMessageShouldRun(unsigned long time_when_started_task) = 0;

    void SayNumberEntered(int number_entered);

    bool GetMayEnterPasscode();
    void SetMayEnterPasscode(bool val);
    virtual bool RunPasscodeReader(int keypad_input) = 0;
    void SetPrintToStart();
    bool GetShouldWait();
};

class SundialCommunicator : public Communicator
{
    protected:
    SundialMessage1 test_message_1;
    SundialHintMessage1 test_hint_message_1;
    int current_passcode_attempt[4] = {0,0,0,0};

    public:
    SundialCommunicator();

    virtual bool CommunicatorMessageShouldRun(unsigned long time_when_started_task);
    virtual void CheckAndRunMessages(unsigned long time_when_started_task, bool repeat_button_was_pressed);
    virtual bool RunPasscodeReader(int keypad_input);
};

class TrojanAndLogicCommunicator : public Communicator
{
    protected:
    TrojanMessage1 trojan_message_1;
    TrojanHintMessage1 test_hint_message_1;
    int current_passcode_attempt = 0;

    public:
    TrojanAndLogicCommunicator();

    virtual bool CommunicatorMessageShouldRun(unsigned long time_when_started_task);
    virtual void CheckAndRunMessages(unsigned long time_when_started_task, bool repeat_button_was_pressed);
    virtual bool RunPasscodeReader(int keypad_input);
};

class SlidingBlocksCommunicator : public Communicator
{
    protected:
    SlidingBlocksMessage1 test_message_1;
    SlidingBlocksHintMessage1 test_hint_message_1;
    
    public:
    SlidingBlocksCommunicator();

    virtual bool CommunicatorMessageShouldRun(unsigned long time_when_started_task);
    virtual void CheckAndRunMessages(unsigned long time_when_started_task, bool repeat_button_was_pressed);
    virtual bool RunPasscodeReader(int keypad_input);
};

class FinalEscapeCommunicator : public Communicator
{
    protected:
    FinalEscapeMessage1 test_message_1;
    FinalEscapeHintMessage1 test_hint_message_1;
    
    public:
    FinalEscapeCommunicator();

    virtual bool CommunicatorMessageShouldRun(unsigned long time_when_started_task);
    virtual void CheckAndRunMessages(unsigned long time_when_started_task, bool repeat_button_was_pressed);
    virtual bool RunPasscodeReader(int keypad_input);
};

#endif