#include "MenuScreen.h"

MenuScreen::MenuScreen()
:Title("Titles Are Still Hard", MAX_X/2+20, CHAR_HEIGHT/2 + 4, MAX_X, CHAR_HEIGHT, LCD.Black),
 Instructions("Instructions", MAX_X/4, 70, 150, 30, LCD.Black, LCD.Black, LCD.White),
 StatsText("Stats", MAX_X/4*3, 70, 150, 30, LCD.Black, LCD.Black, LCD.White),
 Minigames("Minigames", MAX_X/4, 130, 150, 30, LCD.Black, LCD.Black, LCD.White),
 Final_Battle("Final Battle", MAX_X/4*3, 130, 150, 30, LCD.Black, LCD.Black, LCD.White, LCD.Gray),
 Choose_Different_Player("Choose Different Player", MAX_X/2, 190, 250, 30, LCD.Black, LCD.Black, LCD.White)
{
    
}

void MenuScreen::DrawScreen()
{
    LCD.Clear(LCD.Red);

    Title.Draw();
    Instructions.Draw();
    StatsText.Draw();
    Minigames.Draw();
    Choose_Different_Player.Draw();

    Final_Battle.SetEnabled(false);

    Stats& stats = Stats::Instance();

    if(stats.GetCurrentPlayerStats().spot_speed_points >= 1 && stats.GetCurrentPlayerStats().aerodynamics_points >= 1)
        Final_Battle.SetEnabled(true);

    Final_Battle.Draw();
}

void MenuScreen::ScreenTouched(int x, int y)
{
   if(Instructions.WasControlTouched(x,y))
   {
       instructions.StartScreen();
   }
   else if(StatsText.WasControlTouched(x,y))
   {
       stats_screen.StartScreen();
   }
   else if(Minigames.WasControlTouched(x,y))
   {
       mini_menu.StartScreen();
   }
   else if(Final_Battle.WasControlTouched(x,y))
   {
       final_battle.StartScreen();
   }
   else if(Choose_Different_Player.WasControlTouched(x,y))
   {
       //Returns to the PlayerScreen
       ShouldExitScreen = true;
   }
}