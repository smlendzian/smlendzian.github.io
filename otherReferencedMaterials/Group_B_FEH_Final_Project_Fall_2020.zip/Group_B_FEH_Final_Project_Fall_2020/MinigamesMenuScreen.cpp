#include "MinigamesMenuScreen.h"

MinigamesMenuScreen::MinigamesMenuScreen()
:Minigames("Minigames", MAX_X/2, CHAR_HEIGHT/2 + 4, MAX_X, CHAR_HEIGHT, LCD.Black),
 SpotSpeed("Spot Speed", MAX_X/2, 70, 150, 30, LCD.Black, LCD.Black, LCD.White),
 Aerodynamics("Aerodynamics", MAX_X/2, 150, 150, 30, LCD.Black, LCD.Black, LCD.White),
 X("X", MAX_X - CHAR_WIDTH, 4, CHAR_WIDTH, CHAR_HEIGHT, LCD.Black, LCD.Red, LCD.Red)
{
    
}

void MinigamesMenuScreen::DrawScreen()
{
    LCD.Clear(LCD.Red);
    
    Minigames.Draw();
    SpotSpeed.Draw();
    Aerodynamics.Draw();
    X.Draw();
}

void MinigamesMenuScreen::ScreenTouched(int x, int y)
{
   if(SpotSpeed.WasControlTouched(x,y))
   {
       spot_speed.StartScreen();
   }
   else if(Aerodynamics.WasControlTouched(x,y))
   {
       aerodynamics.StartScreen();
   }
   else if(X.WasControlTouched(x,y))
   {
       ShouldExitScreen = true;
   }
}