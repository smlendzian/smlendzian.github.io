#include "AeroDynamicsScreenGame.h"
#include "Controls.h"
#include "FEHRandom.h"
#include "FEHUtility.h"
#include "FEHLCD.h"
#include "Screen.h"



AerodynamicsScreenGame::AerodynamicsScreenGame()
//Draw the 5 Buttons for the Game
:X("X", MAX_X - CHAR_WIDTH, 4, CHAR_WIDTH, CHAR_HEIGHT, LCD.Black, LCD.Red, LCD.Red),
 MoreWeight("Weight", 5, 215, CHAR_WIDTH*6, CHAR_HEIGHT, LCD.Black, LCD.Black, LCD.White),
 MoreLift("Lift", MAX_X-50, 215, CHAR_WIDTH*4, CHAR_HEIGHT, LCD.Black, LCD.Black, LCD.White),
 MoreDrag("Drag",5, 230, CHAR_WIDTH*4, CHAR_HEIGHT, LCD.Black, LCD.Black, LCD.White),
 MorePropulsion("Propulsion", MAX_X-50, 230, CHAR_WIDTH*10, CHAR_HEIGHT, LCD.Black, LCD.Black, LCD.White),
 //Draw the airplane and initial outline and start the game
airplane((MAX_X/4) ,90,(MAX_X/2),90,(MAX_X/4),100,(MAX_X/2), 100,((MAX_X/2)+(MAX_X/4))/2,(((MAX_X/2)+(MAX_X/4))/2) + 20,(((MAX_X/2)+(MAX_X/4))/2) + 20,((MAX_X/2)+(MAX_X/4))/2,(((MAX_X/2)+(MAX_X/4))/2) + 20,(((MAX_X/2)+(MAX_X/4))/2) + 20,90,90,60,100,100 ,130,(MAX_X/2)-3, 95,(MAX_X/2) + 20, 95 ,(MAX_X/2) + 20 , 80,(MAX_X/2) + 20 , 110,5,80,10),
airplaneoutline((MAX_X/4),90,(MAX_X/2),90,(MAX_X/4),100,(MAX_X/2), 100,((MAX_X/2)+(MAX_X/4))/2,(((MAX_X/2)+(MAX_X/4))/2) + 20,(((MAX_X/2)+(MAX_X/4))/2) + 20,((MAX_X/2)+(MAX_X/4))/2,(((MAX_X/2)+(MAX_X/4))/2) + 20,(((MAX_X/2)+(MAX_X/4))/2) + 20,90,90,60,100,100,130,(MAX_X/2)-3, 95,(MAX_X/2) + 20, 95,(MAX_X/2) + 20 , 80,(MAX_X/2) + 20 , 110,5,80,10),
Airplanesleep(1.0)
{

 }



  void AerodynamicsScreenGame::DrawScreen()
{



if (first_draw)
{
    LCD.Clear(LCD.Red);
    X.Draw();
    MoreWeight.Draw();
    MoreLift.Draw();
    MoreDrag.Draw();
    MorePropulsion.Draw();
    airplane.Draw();
    Airplanesleep.Draw();
    airplaneoutline.Draw();
    
}

}


  void AerodynamicsScreenGame::ScreenTouched(int x, int y)
{
int airplaneoutlinef(int a);
    // Exiting the screen
   if(X.WasControlTouched(x,y))
   {
       ShouldExitScreen = true;
   }
   //The force buttons correct the travel of the airplane
   else if(MoreWeight.WasControlTouched(x,y))
   {
    airplaneoutlinef(2);
   }
   else if(MoreDrag.WasControlTouched(x,y))
   {
   airplaneoutlinef(1);    
   }
   else if(MoreLift.WasControlTouched(x,y))
   {

   airplaneoutlinef(4);    
   }
   else if(MorePropulsion.WasControlTouched(x,y))
   {

   airplaneoutlinef(3);    
   }
}
 

  int airplaneoutlinef(int a)
  {
// Cover up the original airplane so the outline can be drawn
LCD.SetDrawColor(RED);
LCD.FillRectangle(0,0,250,200);
LCD.SetDrawColor(GRAY);
LCD.DrawRectangle(25,15,200,150);

int randchangex = rand() % 30 +1;
int randchangey = rand() % 30 +1;
int randchangexx = rand() % 35 -60;
int randchangeyy = rand() % 30 -60;
int cx=0;
int cy=0;



// Generate a random number to change where the outline is drawn
if (a == 1)
{
cx =randchangex;
cy =0;
}
else if (a == 2)
{
cx =0;
cy =randchangey;
}
else if (a == 3)
{
cx =randchangexx;
cy = 0;
}
else if(a==4)
{
 cx = 0;
 cy = randchangeyy;  
}
// Declare the initial variables for where the outline draws
int obigrx11 = MAX_X/4;
int obigry11 = 90;
int obigrx12 = MAX_X/2;
int obigry12 = 90;
int obigrx21 = MAX_X/4;
int obigry21 = 100;
int obigrx22 = MAX_X/2;
int obigry22 = 100;
int obigtx1 = ((MAX_X/2)+(MAX_X/4))/2;
int obigtx2 = (((MAX_X/2)+(MAX_X/4))/2) + 20;
int obigtx3 = (((MAX_X/2)+(MAX_X/4))/2) + 20;
int obigtx4 = ((MAX_X/2)+(MAX_X/4))/2;
int obigtx5 = (((MAX_X/2)+(MAX_X/4))/2) + 20;
int obigtx6 = (((MAX_X/2)+(MAX_X/4))/2) + 20;
int obigt1y = 90;
int obigt2y = 90;
int obigt3y = 60;
int obigt4y = 100;
int obigt5y = 100;
int obigt6y = 130;
int oliltx1 = (MAX_X/2)-3;
int olilt1y = 95;
int oliltx2 =(MAX_X/2)+20;
int olilt2y = 95;
int oliltx3 = (MAX_X/2)+20;
int olilt3y = 80;
int oliltx4 = (MAX_X/2)+20;
int olilt4y = 110;
int oor = 5;
int obwidth = 80;
int obheight = 10;



//Actually drawing the outline with changes
LCD.SetDrawColor(BLACK);
    LCD.DrawRectangle(obigrx11 + cx,obigry11 + cy,obwidth,obheight);
    LCD.DrawCircle(((obigrx21+obigrx11)/2) + cx,((obigry21+obigry11)/2) + cy,oor);
    LCD.DrawLine(obigtx2 + cx,obigt2y + cy,obigtx3 + cx,obigt3y + cy);
    LCD.DrawLine(obigtx4 + cx,obigt4y + cy,obigtx6 + cx,obigt6y + cy);
    LCD.DrawLine(obigtx1 + cx,obigt1y + cy,obigtx3 + cx,obigt3y + cy);
    LCD.DrawLine(obigtx5 + cx,obigt5y + cy,obigtx6 + cx,obigt6y + cy);
    LCD.DrawLine(oliltx1 + cx,olilt1y + cy,oliltx3 + cx,olilt3y + cy);
    LCD.DrawLine(oliltx2 + cx,olilt2y + cy,oliltx3 + cx,olilt3y + cy);
    LCD.DrawLine(oliltx1 + cx,olilt1y + cy,oliltx4 + cx,olilt4y + cy);
    LCD.DrawLine(oliltx2 + cx,olilt2y + cy,oliltx4 + cx,olilt4y + cy);

    //Check to see if the user won the game
    if ((obigt3y + cy)<15)
    {
    Sleep(0.5);
    LCD.SetDrawColor(RED);
    LCD.FillRectangle(0,0,300,240);
    LCD.FillRectangle(150,150,170,90);
    LCD.Write("Minigame Failed!");
    }
    else if ((obigrx11+cx-3)<25)
    {
     Sleep(0.5);
     LCD.SetDrawColor(RED);
     LCD.FillRectangle(0,0,300,240);
     LCD.FillRectangle(150,150,170,90);
     LCD.Write("Minigame Complete!");
     Stats::Instance().GetCurrentPlayerStats().aerodynamics_points++;
     Stats::Instance().Save();
    }
  }  


