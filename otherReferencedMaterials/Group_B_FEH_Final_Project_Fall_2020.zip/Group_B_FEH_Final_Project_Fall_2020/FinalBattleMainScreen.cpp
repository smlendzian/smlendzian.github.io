#include "FinalBattleMainScreen.h"

FinalBattleMainScreen::FinalBattleMainScreen()
:attack_button("Attack", MAX_X/5 - MAX_X/10, 15, MAX_X/5, 30, LCD.Black, LCD.Black, LCD.White, LCD.Gray),
 buff_button("Buff", MAX_X/5*2 - MAX_X/10, 15, MAX_X/5, 30, LCD.Black, LCD.Black, LCD.White, LCD.Gray),
 debuff_button("Debuff", MAX_X/5*3 - MAX_X/10, 15, MAX_X/5, 30, LCD.Black, LCD.Black, LCD.White, LCD.Gray),
 heal_button("Heal", MAX_X/5*4 - MAX_X/10, 15, MAX_X/5, 30, LCD.Black, LCD.Black, LCD.White, LCD.Gray),
 power_button("Power", MAX_X - MAX_X/10, 15, MAX_X/5, 30, LCD.Black, LCD.Black, LCD.White, LCD.Gray),
 player_health_text("300", MAX_X/4, MAX_Y - 10, 30, CHAR_HEIGHT, LCD.Green),
 enemy_health_text("300", MAX_X/4 *3, MAX_Y - 10, 30, CHAR_HEIGHT, LCD.Green),
 you_won("You Won", MAX_X/2, 100, MAX_X, CHAR_HEIGHT, LCD.Black),
 X("X", MAX_X - CHAR_WIDTH, 4, CHAR_WIDTH, CHAR_HEIGHT, LCD.Black, LCD.Red, LCD.Black, LCD.Red)
{

}

void FinalBattleMainScreen::DrawScreen()
{
    if(first_draw)
    {
    X.SetEnabled(false);
    
    LCD.Clear(LCD.Red);

    attack_button.Draw();
    buff_button.Draw();
    debuff_button.Draw();
    heal_button.Draw();
    power_button.Draw();

    player_character.SetCharacter(character_name, 300);
    enemy_character.SetCharacter(FinalBattleCharacter::Gamer, 300);
    enemy_character.SetProjectileText("GAMING");

    player_character.DrawCharacter();
    enemy_character.DrawCharacter();

    player_health_text.Draw();
    enemy_health_text.Draw();
    }
}

void FinalBattleMainScreen::ScreenTouched(int x, int y)
{
   if(attack_button.WasControlTouched(x,y))
   {
      DisableAllButtons();

      player_character.SetProjectileTextBoxToDefault();
      health_change_amount = player_character.Attack(50, 200, player_multiplier_amount, power_player_multiplier_amount, player_miss_rate);

      enemy_character.SubtractFromHealth(health_change_amount);

      EndOfTurn();
   }
   else if(buff_button.WasControlTouched(x,y))
   {
      DisableAllButtons();

      TextBox buff_text("BUFF WAS USED", MAX_X/2, MAX_Y/2, MAX_X, CHAR_HEIGHT, SKYBLUE);
      buff_text.Draw();
      Sleep(3.0);
      buff_text.UnDraw(LCD.Red);

      player_rounds_left_of_buff = 3;
      player_multiplier_amount = 3.0;

      EndOfTurn();
   }
   else if(debuff_button.WasControlTouched(x,y))
   {
      DisableAllButtons();

      TextBox debuff_text("DEBUFF WAS USED", MAX_X/2, MAX_Y/2, MAX_X, CHAR_HEIGHT, SKYBLUE);
      debuff_text.Draw();
      Sleep(3.0);
      debuff_text.UnDraw(LCD.Red);

      player_rounds_left_of_debuff = 3.0;
      enemy_multiplier_amount = 0.5;

      EndOfTurn();
   }
   else if(heal_button.WasControlTouched(x,y))
   {
      DisableAllButtons();

      TextBox heal_text("HEAL WAS USED", MAX_X/2, MAX_Y/2, MAX_X, CHAR_HEIGHT, LCD.Green);
      heal_text.Draw();
      Sleep(3.0);
      heal_text.UnDraw(LCD.Red);

      player_character.Heal(50, 250, player_heal_multiplier);

      EndOfTurn();
   }
   else if(power_button.WasControlTouched(x,y))
   {
      DisableAllButtons();

      TextBox power_text("POWER WAS USED", MAX_X/2, MAX_Y/2, MAX_X, CHAR_HEIGHT, PURPLE);
      power_text.Draw();
      Sleep(3.0);
      power_text.UnDraw(LCD.Red);

      Power();

      EndOfTurn();
   }
}

void FinalBattleMainScreen::Power()
{
    switch(player_character.GetCharacter())
    {
        case FinalBattleCharacter::Brooke:
            player_character.SetProjectileTextBoxToDefault();
            player_character.SetProjectileText("MEOW");
            health_change_amount = player_character.Attack(0, 750, player_multiplier_amount, power_player_multiplier_amount, player_miss_rate);
            enemy_character.SubtractFromHealth(health_change_amount);
            break;
        case FinalBattleCharacter::Erin:
            player_rounds_left_of_power = 2;
            power_enemy_multiplier_amount = 0.25;
            break;
        case FinalBattleCharacter::Jimmy:
            player_rounds_left_of_power = 3;
            player_heal_multiplier = 3;
            break;
        case FinalBattleCharacter::Kyle:
            enemy_miss_rate *= 3;
            player_miss_rate *= 2;
            break;
        case FinalBattleCharacter::Riley:
            player_rounds_left_of_power = 2;
            power_player_multiplier_amount = 4.0;
            break;
    }
}

void FinalBattleMainScreen::EndOfTurn()
{
    //Change text displaying enemy health appropriately.
    enemy_health_text.UnDraw(LCD.Red);
    enemy_health_text.SetText(enemy_character.GetHealth());
    enemy_health_text.Draw();
    Sleep(3.0);
    
    //Implement effects determined by whether the enemy survives.
    if(enemy_character.GetHealth() > 0)
    {
        EnemyTurn();
    }
    else
    {
        EnemyDied();
    }   

    //Change variables related to buffs and debuffs as appropriate.
    AdjustBuffsDebuffsPowers();
}

void FinalBattleMainScreen::SetCharacterName(FinalBattleCharacter::CharacterName character_name_val)
{
    character_name = character_name_val;
}

void FinalBattleMainScreen::DisableAllButtons()
{
    attack_button.SetEnabled(false);
    buff_button.SetEnabled(false);
    debuff_button.SetEnabled(false);
    heal_button.SetEnabled(false);
    power_button.SetEnabled(false);

    attack_button.Draw();
    buff_button.Draw();
    debuff_button.Draw();
    heal_button.Draw();
    power_button.Draw();
}

void FinalBattleMainScreen::EnableAllButtons()
{
    attack_button.SetEnabled(true);
    buff_button.SetEnabled(true);
    debuff_button.SetEnabled(true);
    heal_button.SetEnabled(true);
    power_button.SetEnabled(true);

    attack_button.Draw();
    buff_button.Draw();
    debuff_button.Draw();
    heal_button.Draw();
    power_button.Draw();
}

void FinalBattleMainScreen::EnemyTurn()
{
    //A random number 0 through 3 is generated to determine what the enemy does.
    int action = RandInt() % 4;

    switch(action)
    {
        case 0:
        {
            enemy_character.SetProjectileTextBoxToDefault();
            health_change_amount = enemy_character.Attack(50, 200, enemy_multiplier_amount, power_enemy_multiplier_amount, enemy_miss_rate);
            player_character.SubtractFromHealth(health_change_amount);
        }
        break;
        case 1:
        {
            enemy_rounds_left_of_buff = 3;
            enemy_multiplier_amount = 3.0;

            TextBox buff_text2("BUFF WAS USED", MAX_X/2, MAX_Y/2, MAX_X, CHAR_HEIGHT, SKYBLUE);
            buff_text2.Draw();
            Sleep(3.0);
            buff_text2.UnDraw(LCD.Red);
        }
        break;
        case 2:
        {
            enemy_rounds_left_of_debuff = 3;
            player_multiplier_amount = 0.5;

            TextBox debuff_text2("DEBUFF WAS USED", MAX_X/2, MAX_Y/2, MAX_X, CHAR_HEIGHT, SKYBLUE);
            debuff_text2.Draw();
            Sleep(3.0);
            debuff_text2.UnDraw(LCD.Red);
        }
        break;
        case 3:
        {
            enemy_character.Heal(50, 250, enemy_heal_multiplier);

            TextBox heal_text2("HEAL WAS USED", MAX_X/2, MAX_Y/2, MAX_X, CHAR_HEIGHT, LCD.Green);
            heal_text2.Draw();
            Sleep(3.0);
            heal_text2.UnDraw(LCD.Red);
        }
        break;
    }

    //Change text displaying player health appropriately.
    player_health_text.UnDraw(LCD.Red);
    player_health_text.SetText(player_character.GetHealth());
    player_health_text.Draw();

    //Change text displaying enemy health appropriately.
    enemy_health_text.UnDraw(LCD.Red);
    enemy_health_text.SetText(player_character.GetHealth());
    enemy_health_text.Draw();
    Sleep(3.0);
    
    //Implement effects determined by whether the player survives.
    if(player_character.GetHealth() > 0)
    {
        EnableAllButtons();
    }
    else
    {   
        TextBox you_died("YOU DIED", MAX_X/2, MAX_Y/2, MAX_X, CHAR_HEIGHT, LCD.Black);
        you_died.Draw();
        Sleep(5.0);
        ShouldExitScreen = true;
    }
}

void FinalBattleMainScreen::EnemyDied()
{
    //Character death animation is flashing a yellow rectangle over the character before covering that with the background color.
    enemy_character.UnDrawCharacter(YELLOW);
    Sleep(0.5);
    enemy_character.UnDrawCharacter(LCD.Red);
    enemy_health_text.UnDraw(LCD.Red);

    if(enemy_character.GetCharacter() == FinalBattleCharacter::Gamer)
    {
        enemy_character.SetCharacter(FinalBattleCharacter::TommPizza, 500);
        enemy_character.SetProjectileText("PEPPERS");

        enemy_health_text.SetText(enemy_character.GetHealth());
        enemy_health_text.Draw();

        enemy_character.DrawCharacter();

        //Change text displaying player health appropriately.
        player_health_text.UnDraw(LCD.Red);
        player_character.AddToHealth(300);
        player_health_text.SetText(player_character.GetHealth());
        player_health_text.Draw();

        EnableAllButtons();
    }
    else if(enemy_character.GetCharacter() == FinalBattleCharacter::TommPizza)
    {
        enemy_character.SetCharacter(FinalBattleCharacter::Ladybug, 1000);
        enemy_character.SetProjectileText("LUCKY?");

        enemy_health_text.SetText(enemy_character.GetHealth());
        enemy_health_text.Draw();

        enemy_character.DrawCharacter();

        //Change text displaying player health appropriately.
        player_health_text.UnDraw(LCD.Red);
        player_character.AddToHealth(500);
        player_health_text.SetText(player_character.GetHealth());
        player_health_text.Draw();
            
        EnableAllButtons();
    }
    else if(enemy_character.GetCharacter() == FinalBattleCharacter::Ladybug)
    {
        LCD.Clear(LCD.Red);
            
        you_won.Draw();

        X.SetEnabled(true);
        X.Draw();
    }
}

void FinalBattleMainScreen::AdjustBuffsDebuffsPowers()
{
    if(player_rounds_left_of_buff == 0)
    {
        player_multiplier_amount = 1;
        player_buff_can_be_used = true;
    }
    else if(player_rounds_left_of_buff > 0)
    {
        player_rounds_left_of_buff--;
        player_buff_can_be_used = false;
    }

    if(player_rounds_left_of_debuff == 0)
    {
        enemy_multiplier_amount = 1;
        player_debuff_can_be_used = true;
    }
    else if(player_rounds_left_of_debuff > 0)
    {
        player_rounds_left_of_debuff--;
        player_debuff_can_be_used = false;
    }

    if(player_rounds_left_of_power == 0)
    {
        power_player_multiplier_amount = 1;
        power_enemy_multiplier_amount = 1;
        player_heal_multiplier = 1;
        enemy_heal_multiplier = 1;
        player_power_can_be_used = true;
    }
    else if(player_rounds_left_of_power > 0)
    {
        player_rounds_left_of_power--;
        player_power_can_be_used = false;
    }

    if(enemy_rounds_left_of_buff == 0)
    {
        enemy_multiplier_amount = 1;
        enemy_buff_can_be_used = true;
    }
    else if(enemy_rounds_left_of_buff > 0)
    {
        enemy_rounds_left_of_buff--;
        enemy_buff_can_be_used = false;
    }

    if(enemy_rounds_left_of_debuff == 0)
    {
        player_multiplier_amount = 1;
        enemy_debuff_can_be_used = true;
    }
    else if(enemy_rounds_left_of_debuff > 0)
    {
        enemy_rounds_left_of_debuff--;
        enemy_debuff_can_be_used = false;
    }
}