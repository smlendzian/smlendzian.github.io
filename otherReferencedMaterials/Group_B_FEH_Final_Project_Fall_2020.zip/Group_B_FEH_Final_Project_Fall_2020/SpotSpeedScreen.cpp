#include "SpotSpeedScreen.h"

SpotSpeedScreen::SpotSpeedScreen()
/*This is where all of the buttons and the textboxes are placed onto the screen*/
:SpotSpeed("Spot Speed Screen", MAX_X/2, CHAR_HEIGHT/2 + 4, MAX_X, CHAR_HEIGHT, LCD.Black),
StartSpot("Start", MAX_X/2, 50, 150, 30, LCD.Black, LCD.Black, LCD.White),
X("X", MAX_X - CHAR_WIDTH, 4, CHAR_WIDTH, CHAR_HEIGHT, LCD.Black, LCD.Red, LCD.Red),
SSInstructions("Press the white button when", MAX_X/1.73, 125, 150, 30, BLACK),
SSInstructionstwo("the car moves clode to it.", MAX_X/1.75, 150, 150, 30, BLACK),
SSInstructionsthree("You must earn 5 points", MAX_X/1.85, 175, 150, 30, BLACK),
SSInstructionsfour("to complete the game!", MAX_X/1.85, 200, 150, 30, BLACK)

{

}
/*This makes sure that all of the buttons and textboxes are drawn.*/
void SpotSpeedScreen::DrawScreen()
{
    LCD.Clear(LCD.Red);

    SpotSpeed.Draw();
    X.Draw();
    StartSpot.Draw();
    SSInstructions.Draw();
    SSInstructionstwo.Draw();
    SSInstructionsthree.Draw();
    SSInstructionsfour.Draw();
}
/*This is for the destination when the x button is pressed*/
void SpotSpeedScreen::ScreenTouched(int x, int y)
{
   if(X.WasControlTouched(x,y))
   {
       ShouldExitScreen = true;
   }
   else if(StartSpot.WasControlTouched(x,y))
   {
       Spot.StartScreen();
   }
}