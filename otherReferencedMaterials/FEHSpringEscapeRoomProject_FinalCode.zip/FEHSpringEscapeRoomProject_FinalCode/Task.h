#ifndef Task_h
#define Task_h

#include "Devices.h"
#include "MessagesToCommunicator.h"
#include "Time.h"

//A Task includes everything that communicates with and/or receives instructions from the Arduino 
//during a stage of the Escape Room (ex. a puzzle, sub-puzzle, transition between puzzles/sub-puzzles, etc.).
class Task
{
    protected:
    const char* PROGMEM name;
    bool ShouldEndTask = false; //Used to determine whether to return to the MainMenu
    unsigned long TimeWhenStartedTask;

    public:

    Task(const char* PROGMEM name_val); //Task is given a name for debugging purposes.

    //Starts the Task and runs it until ShouldEndTask becomes true.
    void Start();
    
    //Used in each Task for handling checking each input and the outputs/responses to the inputs
    //(virtual void means that every class derived from the Task class will have the Run() function,
    //but that function will be different for every derived class.)
    virtual void Run() = 0;

    const char* Name();
};

#endif