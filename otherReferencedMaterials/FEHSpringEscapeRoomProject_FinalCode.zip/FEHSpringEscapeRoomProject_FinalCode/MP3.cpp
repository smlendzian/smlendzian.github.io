#include "mp3.h"

//Name list for RAM conservation
const char PROGMEM MP3PotentiometerName[] = "MP3Potentiometer";
const char PROGMEM MP3Name[] = "MP3";

MP3::MP3()
:Device(MP3Name),
mySerial(mp3TXPort, mp3RXPort),
potentiometer(MP3PotentiometerName, mp3PotentiometerPort)
{
    mySerial.begin(9600);
}

void MP3::Play(int audio_file_number)
{
    ExecuteCMD(0x03, highByte(audio_file_number), lowByte(audio_file_number)); 
    //Specifies the track number
    //highByte grabs the top 8 bits and lowByte grabs the bottom 8 bits

    ExecuteCMD(0x0D,0,1); //Plays the currently selected track
}

void MP3::SetVolume(int volume)
{
    ExecuteCMD(0x06, 0, volume); // Set the volume (0x00~0x30)
}

void MP3::AdjustVolumeAsRequested()
{
    int new_volume = potentiometer.ReadPotentiometerAndConvertToSpeakerVolumeValues();
    if(new_volume != current_volume)
    {
        Serial.print(F("VolumeChangeTo: "));
        Serial.println(new_volume);
        SetVolume(new_volume);
        current_volume = new_volume;
    }
}

void MP3::ExecuteCMD(byte CMD, byte Par1, byte Par2)
// Excecute the command and parameters
{
    // Calculate the checksum (2 bytes)
    word checksum = -(Version_Byte + Command_Length + CMD + Acknowledge + Par1 + Par2);
    // Build the command line
    byte Command_line[10] = { Start_Byte, Version_Byte, Command_Length, CMD, Acknowledge,
    Par1, Par2, highByte(checksum), lowByte(checksum), End_Byte};
    //Send the command line to the module
    for (byte k=0; k<10; k++)
    {
        mySerial.write( Command_line[k]);
    }
}