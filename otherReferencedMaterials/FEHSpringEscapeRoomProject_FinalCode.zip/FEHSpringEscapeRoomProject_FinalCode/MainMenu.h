#ifndef MainMenu_h
#define MainMenu_h

#include "Time.h"
#include "Devices.h"
#include "MessagesToCommunicator.h"
#include "Bookcase.h"
#include "Sundial.h"
#include "TrojanAndLogic.h"
#include "SlidingBlocks.h"
#include "FinalEscape.h"

//The MainMenu class is used to cycle through each of the stages of the Escape Room
//(as well as to run tests)
class MainMenu
{
    public:
    Button StartTestButton;

    MainMenu();

    //Waits for the StartTestButton to be pressed before starting the test
    //(used to make sure all physical components are ready before starting the test)
    void WaitForSelection();

    //Starts cycling through the stages of the Escape Room
    void StartEscapeRoom();
};

#endif