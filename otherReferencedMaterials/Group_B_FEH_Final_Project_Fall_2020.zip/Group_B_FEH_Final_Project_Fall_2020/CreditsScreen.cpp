#include "CreditsScreen.h"

CreditsScreen::CreditsScreen()
:Credits("Credits", MAX_X/2, 10, MAX_X, CHAR_HEIGHT, LCD.Black),
 Game_Developers("Game Developers: Lauren Wagner,", MAX_X/2, 30, MAX_X, CHAR_HEIGHT, LCD.Black),
 V_L_S("Vasili Konstantacos, Saran Lendzian", MAX_X/2, 50, MAX_X, CHAR_HEIGHT, LCD.Black),
 Helped_By("Helped By:", MAX_X/2, 70, MAX_X, CHAR_HEIGHT, LCD.Black),
 Help_Line_1("Brooke Morin, Drew Phillips, Riley Jones", MAX_X/2, 90, MAX_X, CHAR_HEIGHT, LCD.Black),
 Help_Line_2("Jimmy McElwain, Kyle Langmack", MAX_X/2, 110, MAX_X, CHAR_HEIGHT, LCD.Black),
 Help_Line_3("Erin Cowen, Scott Lendzian", MAX_X/2, 130, MAX_X, CHAR_HEIGHT, LCD.Black),
 Approved_By_Drew_Phillips("Approved By: Drew Phillips", MAX_X/2, 150, MAX_X, CHAR_HEIGHT, LCD.Black),
 Teacup(150, MAX_X/2 - 50),
 X("X", MAX_X - CHAR_WIDTH, 4, CHAR_WIDTH, CHAR_HEIGHT, LCD.Black, LCD.Red, LCD.Red)
{

}

void CreditsScreen::DrawScreen()
{
    LCD.Clear(LCD.Red);
    
    Credits.Draw();
    Game_Developers.Draw();
    V_L_S.Draw();
    Helped_By.Draw();
    Help_Line_1.Draw();
    Help_Line_2.Draw();
    Help_Line_3.Draw();
    Approved_By_Drew_Phillips.Draw();
    X.Draw();
    Teacup.Draw();
}

void CreditsScreen::ScreenTouched(int x, int y)
{
   if(X.WasControlTouched(x,y))
   {
       ShouldExitScreen = true;
   }
}