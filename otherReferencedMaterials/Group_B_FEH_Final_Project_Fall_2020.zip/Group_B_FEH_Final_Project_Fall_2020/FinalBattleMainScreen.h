#ifndef FinalBattleMainScreen_h 
#define FinalBattleMainScreen_h 

#include "Screen.h"
#include "FinalBattleClasses.h"

//The FinalBattleMainScreen is drawn after a player is selected on the FinalBattleCharacterSelectScreen.
//This Screen includes the full Final Battle.
class FinalBattleMainScreen : public Screen 
{
   private: 

   int health_change_amount;
   int player_rounds_left_of_buff = 0, player_rounds_left_of_debuff = 0, player_rounds_left_of_power = 0;
   int enemy_rounds_left_of_buff = 0, enemy_rounds_left_of_debuff = 0;
   float player_multiplier_amount = 1, enemy_multiplier_amount = 1, player_heal_multiplier = 1, enemy_heal_multiplier = 1, power_player_multiplier_amount = 1, power_enemy_multiplier_amount = 1;
   int enemy_miss_rate = 5, player_miss_rate = 5;
   bool player_buff_can_be_used = true, player_debuff_can_be_used = true, player_power_can_be_used = true;
   bool enemy_buff_can_be_used = true, enemy_debuff_can_be_used = true;

   FinalBattleCharacter::CharacterName character_name;
   ConditionalButton attack_button, buff_button, debuff_button, heal_button, power_button, X;
   FinalBattlePlayerCharacter player_character;
   FinalBattleEnemyCharacter enemy_character;
   TextBox player_health_text, enemy_health_text, you_won;

   public:

   FinalBattleMainScreen();

   virtual void DrawScreen();
   virtual void ScreenTouched(int x, int y);

   void SetCharacterName(FinalBattleCharacter::CharacterName character_name_val);

   //EndOfTurn() carries out the sequence of events that occur the same way regardless of which button the player picked.
   void EndOfTurn();

   //EnemyTurn() carries out the sequence of events that occur if the enemy survives.
   void EnemyTurn();

   //EnemyDied() carries out the sequence of events that occur if the enemy dies.
   void EnemyDied();

   //AdjustBuffsDebuffsPowers() adjusts variables related to buffs, debuffs, and powers as appropriate at the end of a turn.
   void AdjustBuffsDebuffsPowers();

   //Power() carries out the sequence of events that occur if the power_button is selected.
   void Power();

   void DisableAllButtons();
   void EnableAllButtons();
};

#endif