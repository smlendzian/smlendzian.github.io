#include "TeaTimeScreen.h"

TeaTimeScreen::TeaTimeScreen()
:congrats("Congrats", MAX_X/2, 10, MAX_X, CHAR_HEIGHT, LCD.Black),
 you_won("You Won Tea Time With Drew", MAX_X/2, 30, MAX_X, CHAR_HEIGHT, LCD.Black),
 link("https://osu.box.com/s/awd7sm8dpxcnp2b7dosfpqigg95071nd", MAX_X/2, 70, MAX_X, CHAR_HEIGHT, LCD.Black),
 qr_code(MAX_X/2 - 50, 100, 3),
 X("X", MAX_X - CHAR_WIDTH, 4, CHAR_WIDTH, CHAR_HEIGHT, LCD.Black, LCD.Red, LCD.Red)
{

}

void TeaTimeScreen::DrawScreen()
{
    LCD.Clear(LCD.Red);
    
    congrats.Draw();
    you_won.Draw();
    link.Draw();
    X.Draw();
    qr_code.Draw();
}

void TeaTimeScreen::ScreenTouched(int x, int y)
{
   if(X.WasControlTouched(x,y))
   {
       ShouldExitScreen = true;
   }
}