#ifndef MainInstructionsScreen_h 
#define MainInstructionsScreen_h 

#include "Screen.h"
#include "CreditsScreen.h"

//The MainInstructionsScreen is drawn after the appropriate Button is clicked on the MenuScreen.
//The instructions for the game are displayed here.
//The CreditsScreen can be accessed from this Screen.
//The player can return to the MenuScreen.
class MainInstructionsScreen : public Screen 
{
   private:
   TextBox Instructions, Complete_all_the_Minigames, to_unlock_the_Final_Battle, Win_the_Final_Battle_to_Win_a, New_Tea_Time_with_Drew; 
   Button X, Credits;

   protected:
   CreditsScreen credits;

   public:

   MainInstructionsScreen();

   virtual void DrawScreen();
   virtual void ScreenTouched(int x, int y);
};

#endif