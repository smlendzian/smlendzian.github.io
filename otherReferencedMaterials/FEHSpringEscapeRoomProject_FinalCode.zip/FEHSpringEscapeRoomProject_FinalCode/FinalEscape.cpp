#include "FinalEscape.h"

//Name list for RAM conservation
const char PROGMEM FinalEscapeName[] = "FinalEscape";
const char PROGMEM StartTestButtonName[] = "StartTestButton";

FinalEscape::FinalEscape()
:Task(FinalEscapeName),
StartTestButton(StartTestButtonName, DigitalSensor::Mux1, StartTestButtonPort)
{
    
}

void FinalEscape::Run()
{
    while(!ShouldEndTask) //Loop is redundant but used for clarity
    {
        communicator.RunCommunicator(Task::TimeWhenStartedTask);

        //Check whether the button was not pressed before but is pressed now.
        if(!StartTestButton.ButtonWasPressed() && StartTestButton.ButtonIsPressed())
        //Checks the previous reading variable, and then does a new reading
        //(changing that variable, so the order of this if statement is important)
        {
            Serial.print(StartTestButton.Name());
            Serial.println(F("WasPressed"));
        }
        //Check whether the button was pressed before but is released now.
        else if(StartTestButton.ButtonWasPressed() && StartTestButton.ButtonIsReleased())
        {
            Serial.print(StartTestButton.Name());
            Serial.println(F("WasReleased"));
            Serial.println(F("EscapeRoomFinished!!!"));
            ShouldEndTask = true;   //Ends the loop in Task::Start() to return to the MainMenu
        }
    }
}