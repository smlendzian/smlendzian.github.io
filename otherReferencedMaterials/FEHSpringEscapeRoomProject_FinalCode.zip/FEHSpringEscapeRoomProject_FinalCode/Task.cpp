#include "Task.h"

Task::Task(const char* PROGMEM name_val)
:name(name_val)
{

}

void Task::Start()
{
    TimeWhenStartedTask = TheTime.GetTimeSinceEscapeRoomStartedInMilliseconds();
    Serial.print(Name());
    Serial.print(F(" Started At "));
    Serial.println(TimeWhenStartedTask);
    
    //Task continues until ShouldEndTask is changed to true.
    //Then the program will return to the MainMenu
    while(!ShouldEndTask) 
    {
        Run();
    } 
}

const char* PROGMEM Task::Name()
{
    return name;
}