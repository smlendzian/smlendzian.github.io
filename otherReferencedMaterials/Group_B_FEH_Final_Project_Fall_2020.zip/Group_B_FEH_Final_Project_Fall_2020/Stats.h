#ifndef Stats_h
#define Stats_h

#include "FEHSD.h"
#include <string>  

using namespace std;

class PlayerStats
{
    public:

    enum PlayerNames
    {
        Arson,
        Riot,
        Tax_Fraud
    };

    int spot_speed_points = 0, aerodynamics_points = 0, final_battle_wins = 0;

    int player_name;
};

//Stats is a singleton class used to manage all the Stats for the entire game.
class Stats
{
    private:
    static Stats* instance;

    PlayerStats player_stats_arson;
    PlayerStats player_stats_riot;
    PlayerStats player_stats_tax_fraud;

    Stats();
    
    public:
    static Stats& Instance();
    static void Destroy();

    void Load();
    void Save();

    PlayerStats& GetPlayerStats(PlayerStats::PlayerNames name);

    PlayerStats& GetCurrentPlayerStats();

    PlayerStats::PlayerNames current_player;

    string GetPlayerNameText();
};

#endif