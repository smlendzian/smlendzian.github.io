#ifndef AerodynamicsScreenGame_h 
#define AerodynamicsScreenGame_h 

#include "Screen.h"


//After clicking the appropriate Button on the AeroDynamicsScreen, the player is brought to this Screen.
class AerodynamicsScreenGame : public Screen 
{
   private:
   airplane airplane;
   airplaneoutline airplaneoutline;
   Airplanesleep Airplanesleep;
   Button MoreWeight;
   Button MoreLift;
   Button MoreDrag;
   Button MorePropulsion;
   Button X;
   public:

   AerodynamicsScreenGame();

   virtual void DrawScreen();
   virtual void ScreenTouched(int x, int y);
};

#endif