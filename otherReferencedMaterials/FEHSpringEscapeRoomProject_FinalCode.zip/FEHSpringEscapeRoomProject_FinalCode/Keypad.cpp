#include "Keypad.h"

//Name list for RAM conservation
const char PROGMEM KeypadButton0Name[] = "KeypadButton0";
const char PROGMEM KeypadButton1Name[] = "KeypadButton1";
const char PROGMEM KeypadButton2Name[] = "KeypadButton2";
const char PROGMEM KeypadButton3Name[] = "KeypadButton3";
const char PROGMEM KeypadButton4Name[] = "KeypadButton4";
const char PROGMEM KeypadButton5Name[] = "KeypadButton5";
const char PROGMEM KeypadButton6Name[] = "KeypadButton6";
const char PROGMEM KeypadButton7Name[] = "KeypadButton7";
const char PROGMEM KeypadButton8Name[] = "KeypadButton8";
const char PROGMEM KeypadButton9Name[] = "KeypadButton9";
const char PROGMEM KeypadButtonReplayLastMessageName[] = "KeypadButtonReplayLastMessage";

KeypadButton::KeypadButton(const char* PROGMEM name_val, PortLocation port_location_val, int port_num, int button_num, long initial_state_val)
:Button(name_val, port_location_val, port_num, initial_state_val),
button_number(button_num)
{

}

int KeypadButton::GetButtonNumber()
{
    return button_number;
}

bool KeypadButton::GetButtonWasClicked(){
    return buttonWasClicked;
}

void KeypadButton::CheckIfButtonWasClicked(){
    
    if(!ButtonWasPressed() && ButtonIsPressed())
    {
        Serial.print(Name());
        Serial.println(F("WasPressed"));
    }
    else if(ButtonWasPressed() && ButtonIsReleased())
    {
        Serial.print(Name());
        Serial.println(F("WasReleased"));

        SetButtonWasClicked(true);
    }
}

void KeypadButton::SetButtonWasClicked(bool button_was_pressed_correctly_val)
{
    buttonWasClicked = button_was_pressed_correctly_val;
}

Keypad::Keypad(const char* PROGMEM name_val)
:KeypadButton0(KeypadButton0Name, DigitalSensor::Mux1, KeypadButton0Port, 0),
KeypadButton1(KeypadButton1Name, DigitalSensor::Mux1, KeypadButton1Port, 1),
KeypadButton2(KeypadButton2Name, DigitalSensor::Mux1, KeypadButton2Port, 2),
KeypadButton3(KeypadButton3Name, DigitalSensor::Mux1, KeypadButton3Port, 3),
KeypadButton4(KeypadButton4Name, DigitalSensor::Mux1, KeypadButton4Port, 4),
KeypadButton5(KeypadButton5Name, DigitalSensor::Mux1, KeypadButton5Port, 5),
KeypadButton6(KeypadButton6Name, DigitalSensor::Mux1, KeypadButton6Port, 6),
KeypadButton7(KeypadButton7Name, DigitalSensor::Mux1, KeypadButton7Port, 7),
KeypadButton8(KeypadButton8Name, DigitalSensor::Mux1, KeypadButton8Port, 8),
KeypadButton9(KeypadButton9Name, DigitalSensor::Mux1, KeypadButton9Port, 9),
KeypadButtonReplayLastMessage(KeypadButtonReplayLastMessageName, DigitalSensor::Mux1, KeypadButtonReplayLastMessagePort, 10)
{
}

int Keypad::Run() 
{
    int which_button_was_clicked = -1;

    which_button_was_clicked = CheckButton(KeypadButton0);
    if(which_button_was_clicked == -1)
    {
        which_button_was_clicked = CheckButton(KeypadButton1);
    }
    if(which_button_was_clicked == -1)
    {
        which_button_was_clicked = CheckButton(KeypadButton2);
    }
    if(which_button_was_clicked == -1)
    {
        which_button_was_clicked = CheckButton(KeypadButton3);
    }
    if(which_button_was_clicked == -1)
    {
        which_button_was_clicked = CheckButton(KeypadButton4);
    }
    if(which_button_was_clicked == -1)
    {
        which_button_was_clicked = CheckButton(KeypadButton5);
    }
    if(which_button_was_clicked == -1)
    {
        which_button_was_clicked = CheckButton(KeypadButton6);
    }
    if(which_button_was_clicked == -1)
    {
        which_button_was_clicked = CheckButton(KeypadButton7);
    }
    if(which_button_was_clicked == -1)
    {
        which_button_was_clicked = CheckButton(KeypadButton8);
    }
    if(which_button_was_clicked == -1)
    {
        which_button_was_clicked = CheckButton(KeypadButton9);
    }
    if(which_button_was_clicked == -1)
    {
        which_button_was_clicked = CheckButton(KeypadButtonReplayLastMessage);
    }

    return which_button_was_clicked;
}

int Keypad::CheckButton(KeypadButton& button)
{
    int which_button_was_clicked = -1;

    button.CheckIfButtonWasClicked();

    if(button.GetButtonWasClicked()){
        button.SetButtonWasClicked(false); //set it back to false because this isn't being ordered, and if it can't change back to false/true, it can't be pressed again
        which_button_was_clicked = button.GetButtonNumber();
    }

    return which_button_was_clicked;
}

bool Keypad::ANumberButtonWasClicked()
{
    int which_button_was_clicked = Run();
    return !(which_button_was_clicked == 10 || which_button_was_clicked == -1);
}
