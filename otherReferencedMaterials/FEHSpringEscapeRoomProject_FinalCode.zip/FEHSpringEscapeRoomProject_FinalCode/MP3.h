//Code inspired by https://www.electronics-lab.com/project/mp3-player-using-arduino-dfplayer-mini/
//Using the MP3-TF-16P DFPlayer Module (https://usermanual.wiki/Manual/DFPlayerMiniManual.234442183/pdf)

#ifndef MP3_h
#define MP3_h

#include "Devices.h"

#include "SoftwareSerial.h"
# define Start_Byte 0x7E
# define Version_Byte 0xFF
# define Command_Length 0x06
# define End_Byte 0xEF
# define Acknowledge 0x00 //Returns info with command 0x41 [0x01: info, 0x00: no info]
# define ACTIVATED LOW

//This class handles the mp3 player module commands.
class MP3 : public Device
{
    SoftwareSerial mySerial;
    MP3Potentiometer potentiometer;
    int current_volume = -1;

    void ExecuteCMD(byte CMD, byte Par1, byte Par2);

    public:
    MP3();
    void SetVolume(int volume);
    void Play(int audio_file_number);
    void AdjustVolumeAsRequested(); //uses the potentiometer
};

#endif