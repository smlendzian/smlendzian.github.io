#include "MainMenu.h"

//Name list for RAM conservation
const char PROGMEM StartTestButtonName[] = "StartTestButton";
const char PROGMEM BookcaseServoName[] = "BookcaseServo";
const char PROGMEM SlidingBlocksServoName[] = "SlidingBlocksServo";

MainMenu::MainMenu()
:StartTestButton(StartTestButtonName, DigitalSensor::Mux1, StartTestButtonPort)
{
    Serial.println(F("MainMenuConstructor"));
}

void MainMenu::StartEscapeRoom()
{
    Serial.println(F("MainMenuStarted"));

    //Repeats test/escape room indefinitely
    while(true)
    {
        Serial.println(freeMemory());
        Serial.println(F("LoopStarted"));
        Serial.println(freeMemory());
        WaitForSelection();
        Serial.println(F("StartButtonWasClicked"));
        Serial.println(freeMemory());
        LEDBank::TurnOffAllLEDs();

        {
            ServoDevice bookcase_servo(BookcaseServoName, BookcaseDoorServoPort, 0);
            bookcase_servo.MoveToInitialPosition();
            delay(3000);
            //delay needed to give the motor time to turn before it is destroyed
            //use of delay is acceptable for servos in this program since nothing needs to happen in parallel with a servo move
        } //ServoDevice destructor is called after the closing curly brace

        {
            ServoDevice sliding_blocks_servo(SlidingBlocksServoName, SlidingBlocksServoPort, 180);
            sliding_blocks_servo.MoveToInitialPosition();
            delay(3000);
        } //ServoDevice destructor is called after the closing curly brace */

        delay(100);

        TheTime.ResetTimeSinceEscapeRoomStarted();
        Serial.println(freeMemory());

        SevenSegmentDisplay::DisplayDigit(5);

        //Creates an instance of the Bookcase class
        Bookcase book_case;
        //Starts the Bookcase puzzle
        book_case.Start();

        SevenSegmentDisplay::DisplayDigit(4);

        //Creates an instance of the Sundial class
        Serial.println(F("rightbeforsundial"));
        Sundial sundial;
        Serial.println(F("sundialconstructor?"));
        //Starts the Sundial puzzle
        sundial.Start();

        SevenSegmentDisplay::DisplayDigit(3);

        //Creates an instance of the TrojanAndLogic class
        TrojanAndLogic trojan_and_logic;
        //Starts the TrojanAndLogic puzzle
        trojan_and_logic.Start();

        SevenSegmentDisplay::DisplayDigit(2);

        //This is called a second time to reset the physical prototype for the next puzzle.
        //For the real room, this would not be needed because each puzzle would have a separate servo.
        delay(2000);
        {
            ServoDevice sliding_blocks_servo(SlidingBlocksServoName, SlidingBlocksServoPort, 180);
            sliding_blocks_servo.MoveToInitialPosition();
            delay(3000);
        } //ServoDevice destructor is called after the closing curly brace
        Serial.println(F("ServoWasResetAgainForSlidingBlocks"));

        //Creates an instance of the SlidingBlocks class
        SlidingBlocks sliding_blocks;
        //Starts the SlidingBlocks puzzle
        sliding_blocks.Start();

        SevenSegmentDisplay::DisplayDigit(1);

        //Creates an instance of the FinalEscape class
        //(un-comment the lines of code if enough RAM is available to run this task)
        //FinalEscape final_escape;
        //Starts the FinalEscape Task
        //final_escape.Start();

        SevenSegmentDisplay::DisplayDigit(0);

        WaitForSelection();

        LEDBank::TurnOffAllLEDs();
        SevenSegmentDisplay::TurnOffDisplay();
        LiquidCrystalShiftRegister lcd(LCDLatchPort);
        lcd.clear();
    }   
    
}

void MainMenu::WaitForSelection()
{
    Serial.println(F("WaitForSelectionStarted"));
    StartTestButton.WaitForButtonClick();
}