#include "Stats.h"

Stats* Stats::instance = NULL;

Stats::Stats()
{
    //Create default stats.
    player_stats_arson.player_name = PlayerStats::Arson;
    player_stats_riot.player_name = PlayerStats::Riot;
    player_stats_tax_fraud.player_name = PlayerStats::Tax_Fraud;
}

Stats& Stats::Instance()
{
    if(instance == NULL)
    {
        instance = new Stats();
    }
    
    return *instance;
}

void Stats::Destroy()
{
    delete instance;
    instance = NULL;
}

void Stats::Load()
{
    FEHFile* stats_file = SD.FOpen("stats.txt", "r");

    if(stats_file != 0)
    {
        int val;

        SD.FScanf(stats_file, "%d", &val);
        player_stats_arson.spot_speed_points = val;

        SD.FScanf(stats_file, "%d", &val);
        player_stats_arson.aerodynamics_points = val;

        SD.FScanf(stats_file, "%d", &val);
        player_stats_arson.final_battle_wins = val;


        SD.FScanf(stats_file, "%d", &val);
        player_stats_riot.spot_speed_points = val;

        SD.FScanf(stats_file, "%d", &val);
        player_stats_riot.aerodynamics_points = val;

        SD.FScanf(stats_file, "%d", &val);
        player_stats_riot.final_battle_wins = val;


        SD.FScanf(stats_file, "%d", &val);
        player_stats_tax_fraud.spot_speed_points = val;

        SD.FScanf(stats_file, "%d", &val);
        player_stats_tax_fraud.aerodynamics_points = val;

        SD.FScanf(stats_file, "%d", &val);
        player_stats_riot.final_battle_wins = val;

        SD.FClose(stats_file);
    }
}

void Stats::Save()
{
    FEHFile* stats_file = SD.FOpen("stats.txt", "w");

    SD.FPrintf(stats_file, "%d %d %d %d %d %d %d %d %d", player_stats_arson.spot_speed_points, 
            player_stats_arson.aerodynamics_points, player_stats_arson.final_battle_wins, 
            player_stats_riot.spot_speed_points, player_stats_riot.aerodynamics_points, player_stats_riot.final_battle_wins,
            player_stats_tax_fraud.spot_speed_points, player_stats_tax_fraud.aerodynamics_points, player_stats_tax_fraud.final_battle_wins);

    SD.FClose(stats_file);
}

PlayerStats& Stats::GetPlayerStats(PlayerStats::PlayerNames name)
{
    switch(name)
    {
        case PlayerStats::Arson:
        {
            return player_stats_arson; 
        }
        case PlayerStats::Riot:
        {
            return player_stats_riot; 
        }
        case PlayerStats::Tax_Fraud:
        {
            return player_stats_tax_fraud; 
        }
    }
    return player_stats_arson;
}

PlayerStats& Stats::GetCurrentPlayerStats()
{
    return GetPlayerStats(current_player);
}

string Stats::GetPlayerNameText()
{
    switch(current_player)
    {
        case PlayerStats::Arson:
        {
            return "Arson"; 
        }
        case PlayerStats::Riot:
        {
            return "Riot"; 
        }
        case PlayerStats::Tax_Fraud:
        {
            return "Tax Fraud"; 
        }
    }
    return "Arson";
}