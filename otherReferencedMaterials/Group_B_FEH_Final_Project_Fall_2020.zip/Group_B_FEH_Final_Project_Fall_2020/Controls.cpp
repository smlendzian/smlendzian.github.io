#include "Controls.h"

Control::Control(int x_val, int y_val, int w, int h)
{
    x=x_val;
    y=y_val;
    width=w;
    height=h;
    x_start = x - width/2;
    y_start = y - height/2;
}

void Control::UpdateLocation(int x_new, int y_new)
{
    x = x_new;
    y = y_new;
    x_start = x - width/2;
    y_start = y - height/2;
}

void Control::UnDraw(int background_color)
{
    LCD.SetDrawColor(background_color);
    LCD.FillRectangle(x_start, y_start, width, height);
}

void Control::DrawBoxAround(int added_width, int added_height, int box_color)
{
    LCD.SetDrawColor(box_color);
    
    int x_box_start = x_start - added_width / 2;
    int y_box_start = y_start - added_height / 2;

    LCD.DrawRectangle(x_box_start, y_box_start, width + added_width, height + added_height);
}

TextBox::TextBox(const char*text_val, int x_val, int y_val, int w, int h, int color)
:Control(x_val, y_val, w, h),
 text(text_val),
 text_color(color)
{
    len = text.size();
}

void TextBox::Draw()
{
    int text_width = len * CHAR_WIDTH;

    int x_text_start = x - text_width / 2;
    int y_text_start = y - CHAR_HEIGHT / 2;
    
    LCD.SetFontColor(text_color);
    LCD.WriteAt(text.c_str(), x_text_start, y_text_start);
}

void TextBox::SetText(const char*text_val)
{
    text = text_val;
}

void TextBox::SetText(int int_val)
{
    text = std::to_string(int_val);
}

Button::Button(const char*text_val, int x_val, int y_val, int w, int h, int color_text, int color_border, int color_fill)
:TextBox(text_val, x_val, y_val, w, h, color_text),
 border_color(color_border),
 fill_color(color_fill)
{

}

void Button::Draw()
{
    LCD.SetDrawColor(fill_color);
    LCD.FillRectangle(x_start, y_start, width, height);

    LCD.SetDrawColor(border_color);
    LCD.DrawRectangle(x_start, y_start, width, height);

    TextBox::Draw();
}

bool Button::WasControlTouched(int x_val, int y_val)
{
    return x_val >= x_start &&
           x_val <= x_start + width &&
           y_val >= y_start &&
           y_val <= y_start + height;
}

ConditionalButton::ConditionalButton(const char*text_val, int x_val, int y_val, int w, int h, int color_text, int color_border, int color_fill_true, int color_fill_false)
:Button(text_val, x_val, y_val, w, h, color_text, color_border, color_fill_true),
 true_color_fill(color_fill_true),
 false_color_fill(color_fill_false),
 is_enabled(true)
{

}

void ConditionalButton::SetEnabled(bool is_enabled_val)
{
    is_enabled = is_enabled_val;
}

void ConditionalButton::Draw()
{
    if(is_enabled)
        LCD.SetDrawColor(true_color_fill);
    else
        LCD.SetDrawColor(false_color_fill);

    LCD.FillRectangle(x_start, y_start, width, height);

    LCD.SetDrawColor(border_color);
    LCD.DrawRectangle(x_start, y_start, width, height);

    TextBox::Draw();
}

bool ConditionalButton::WasControlTouched(int x_val, int y_val)
{
    return x_val >= x_start &&
           x_val <= x_start + width &&
           y_val >= y_start &&
           y_val <= y_start + height &&
           is_enabled;
}

airplane::airplane(float abigrx11,float abigry11,float abigrx12,float abigry12,float abigrx21,float abigry21,float abigrx22, float abigry22,float abigt1x,float abigt2x,float abigt3x,float abigt4x,float abigt5x,float abigt6x,float abigt1y,float abigt2y,float abigt3y,float abigt4y,float abigt5y,float abigt6y,float alilt1x,float alilt1y,float alilt2x,float alilt2y,float alilt3x,float alilt3y,float alilt4x,float alilt4y, int ar,int abwidth, int abheight)
:bigrx11(abigrx11),
bigry11(abigry11),
bigrx12(abigrx12),
bigry12(abigry12),
bigrx21(abigrx21),
bigry21(abigry21),
bigrx22(abigrx22),
bigt1x(abigt1x),
bigt2x(abigt2x),
bigt3x(abigt3x),
bigt4x(abigt4x),
bigt5x(abigt5x),
bigt6x(abigt6x),
bigt1y(abigt1y),
bigt2y(abigt2y),
bigt3y(abigt3y),
bigt4y(abigt4y),
bigt5y(abigt5y),
bigt6y(abigt6y),
lilt1y(alilt1y),
lilt2y(alilt2y),
lilt3y(alilt3y),
lilt4y(alilt4y),
lilt1x(alilt1x),
lilt2x(alilt2x),
lilt3x(alilt3x),
lilt4x(alilt4x),
r(ar),
bwidth(abwidth),
bheight(abheight)
{

}

airplaneoutline::airplaneoutline(float oabigrx11,float oabigry11,float oabigrx12,float oabigry12,float oabigrx21,float oabigry21,float oabigrx22, float oabigry22,float oabigt1x,float oabigt2x,float oabigt3x,float oabigt4x,float oabigt5x,float oabigt6x,float oabigt1y,float oabigt2y,float oabigt3y,float oabigt4y,float oabigt5y,float oabigt6y,float oalilt1x,float oalilt1y,float oalilt2x,float oalilt2y,float oalilt3x,float oalilt3y,float oalilt4x,float oalilt4y, int oar,int oabwidth, int oabheight)
:obigrx11(oabigrx11),
obigry11(oabigry11),
obigrx12(oabigrx12),
obigry12(oabigry12),
obigrx21(oabigrx21),
obigry21(oabigry21),
obigrx22(oabigrx22),
obigt1x(oabigt1x),
obigt2x(oabigt2x),
obigt3x(oabigt3x),
obigt4x(oabigt4x),
obigt5x(oabigt5x),
obigt6x(oabigt6x),
obigt1y(oabigt1y),
obigt2y(oabigt2y),
obigt3y(oabigt3y),
obigt4y(oabigt4y),
obigt5y(oabigt5y),
obigt6y(oabigt6y),
olilt1y(oalilt1y),
olilt2y(oalilt2y),
olilt3y(oalilt3y),
olilt4y(oalilt4y),
olilt1x(oalilt1x),
olilt2x(oalilt2x),
olilt3x(oalilt3x),
olilt4x(oalilt4x),
oor(oar),
obwidth(oabwidth),
obheight(oabheight)
{

}



void airplane::Draw()
{
    LCD.SetDrawColor(GRAY);
    LCD.FillRectangle(bigrx11,bigry11,bwidth,bheight);
    LCD.FillCircle((bigrx21+bigrx11)/2,(bigry21+bigry11)/2,r);
    // Filling in top wing
    for (int i=1;i<=30;i++)
    {
    LCD.DrawLine(bigt2x-i,bigt2y,bigt3x,bigt3y+i);  
    }
    LCD.DrawLine(bigt2x,bigt2y,bigt3x,bigt3y);
    //Filling in bottom wing
 for (int j=1;j<=30;j++)
    {
    LCD.DrawLine(bigt5x-j,bigt5y,bigt6x,bigt6y-j);  
    }
    LCD.DrawLine(bigt4x,bigt4y,bigt6x,bigt6y);
    //Filling in bottom wing
    for (int j=1;j<=15;j++)
    {
    LCD.DrawLine(bigt4x+j,bigt4y+j,bigt6x,bigt6y-j);
    LCD.DrawLine(bigt4x+j,bigt4y+j,bigt6x-8,bigt6y-12-j);
    LCD.DrawLine(bigt4x+j,bigt4y+j,bigt6x-8,bigt6y-12);
    LCD.DrawLine(bigt6x,bigt6y-j,bigt4x,bigt4y);
    LCD.DrawLine(bigt4x+j,bigt4y+j,bigt5x,bigt5y);   
    LCD.DrawLine(bigt5x-j,bigt5y,bigt6x,bigt6y-20); 
    }
    //Filling in top wing
    for (int j=1;j<=15;j++)
    {
    LCD.DrawLine(bigt1x+j,bigt1y+j,bigt3x,bigt3y+j);
    LCD.DrawLine(bigt1x+j,bigt1y-j,bigt3x-8,bigt3y+12+j);
    LCD.DrawLine(bigt1x+j,bigt1y-j,bigt3x-8,bigt3y+12);
    LCD.DrawLine(bigt3x,bigt3y+j,bigt1x,bigt1y);
    LCD.DrawLine(bigt1x+j,bigt1y-j,bigt2x,bigt2y);   
    LCD.DrawLine(bigt2x-j,bigt2y,bigt3x,bigt3y+20); 
    }
    //filling in bottom wing
    for (int j=1;j<=12;j++)
    {
LCD.DrawLine(bigt5x-j,bigt5y,bigt6x-j,bigt6y-20); 
    }
     //filling in top wing
    for (int j=1;j<=12;j++)
    {
LCD.DrawLine(bigt2x-j,bigt2y,bigt3x-j,bigt3y+20); 
    }
  

    LCD.DrawLine(bigt1x,bigt1y,bigt3x,bigt3y);
    LCD.DrawLine(bigt5x,bigt5y,bigt6x,bigt6y);
    LCD.DrawLine(lilt1x,lilt1y,lilt2x,lilt2y);
    LCD.DrawLine(lilt1x,lilt1y,lilt3x,lilt3y);
    LCD.DrawLine(lilt2x,lilt2y,lilt3x,lilt3y);
    LCD.DrawLine(lilt1x,lilt1y,lilt4x,lilt4y);
    LCD.DrawLine(lilt2x,lilt2y,lilt4x,lilt4y);
    //Filling in tail
     for (int j=1;j<=15;j++)
    {
LCD.DrawLine(lilt3x-j,lilt3y+j,lilt4x-j,lilt4y-j); 
    }
     for (int j=1;j<=5;j++)
    {
    LCD.DrawLine(lilt1x,lilt1y+j,lilt3x,lilt3y+j); 
    }   
     for (int j=1;j<=5;j++)
    {
    LCD.DrawLine(lilt1x,lilt1y-j,lilt4x,lilt4y-j); 
    }  
}

void airplaneoutline::Draw()
{
LCD.SetDrawColor(BLACK);
    LCD.DrawRectangle(obigrx11,obigry11,obwidth,obheight);
    LCD.DrawCircle((obigrx21+obigrx11)/2,(obigry21+obigry11)/2,oor);
    LCD.DrawLine(obigt2x,obigt2y,obigt3x,obigt3y);
    LCD.DrawLine(obigt4x,obigt4y,obigt6x,obigt6y);
    LCD.DrawLine(obigt1x,obigt1y,obigt3x,obigt3y);
    LCD.DrawLine(obigt5x,obigt5y,obigt6x,obigt6y);
    LCD.DrawLine(olilt1x,olilt1y,olilt3x,olilt3y);
    LCD.DrawLine(olilt2x,olilt2y,olilt3x,olilt3y);
    LCD.DrawLine(olilt1x,olilt1y,olilt4x,olilt4y);
    LCD.DrawLine(olilt2x,olilt2y,olilt4x,olilt4y);
}

Airplanesleep::Airplanesleep(float TimeSleep)
:time_sleep(TimeSleep)
{

}

void Airplanesleep::Draw()
{
   Sleep(time_sleep);
}