#ifndef MinigamesMenuScreen_h 
#define MinigamesMenuScreen_h 

#include "Screen.h"
#include "SpotSpeedScreen.h"
#include "AerodynamicsScreen.h"

//After clicking the appropriate Button on the MenuScreen, this Screen will come up.
//From this Screen, the player can click the appropriate Button to go to the desired Minigame
//or the player can return to the MenuScreen.
class MinigamesMenuScreen : public Screen 
{
   private:
   TextBox Minigames;
   Button X, SpotSpeed, Aerodynamics;

   protected:
   SpotSpeedScreen spot_speed;
   AerodynamicsScreen aerodynamics;

   public:

   MinigamesMenuScreen();

   virtual void DrawScreen();
   virtual void ScreenTouched(int x, int y);
};

#endif