#include "MainInstructionsScreen.h"

MainInstructionsScreen::MainInstructionsScreen()
:Instructions("Instructions:", MAX_X/2+10, 35, MAX_X, CHAR_HEIGHT, LCD.Black),
 Complete_all_the_Minigames("Complete all the Minigames", MAX_X/2+10, 70, MAX_X, CHAR_HEIGHT, LCD.Black),
 to_unlock_the_Final_Battle("to unlock the Final Battle", MAX_X/2+20, 90, MAX_X, CHAR_HEIGHT, LCD.Black),
 Win_the_Final_Battle_to_Win_a("Win the Final Battle to Win a", MAX_X/2+20, 110, MAX_X, CHAR_HEIGHT, LCD.Black),
 New_Tea_Time_with_Drew("New Tea Time with Drew", MAX_X/2, 130, MAX_X, CHAR_HEIGHT, LCD.Black),
 X("X", MAX_X - CHAR_WIDTH, 4, CHAR_WIDTH, CHAR_HEIGHT, LCD.Black, LCD.Red, LCD.Red),
 Credits("Credits", MAX_X/2, 180, 150, 30, LCD.Black, LCD.Black, LCD.White)
{

}

void MainInstructionsScreen::DrawScreen()
{
    LCD.Clear(LCD.Red);

    Instructions.Draw();
    Complete_all_the_Minigames.Draw();
    to_unlock_the_Final_Battle.Draw();
    Win_the_Final_Battle_to_Win_a.Draw();
    New_Tea_Time_with_Drew.Draw();

    X.Draw();
    Credits.Draw();
}

void MainInstructionsScreen::ScreenTouched(int x, int y)
{
   if(X.WasControlTouched(x,y))
   {
       ShouldExitScreen = true;
   }
   else if(Credits.WasControlTouched(x,y))
   {
       credits.StartScreen();
   }
}