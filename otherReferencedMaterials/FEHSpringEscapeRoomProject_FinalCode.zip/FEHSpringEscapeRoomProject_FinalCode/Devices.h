//This is to ensure that this file is only included once when it is compiled.
#ifndef Devices_h
#define Devices_h

#include <Arduino.h>
#include <Servo.h>
#include "Time.h"

//All ports are defined here so that ports can be easily changed/referenced when wiring the physical prototype.

#define Mux1_SIG_Port 7
#define Mux1_S0_Port 14 //A0
#define Mux1_S1_Port 15 //A1
#define Mux1_S2_Port 16 //A2
#define Mux1_S3_Port 17 //A3
#define Mux1_S4_Port 18 //A4

#define MainShiftRegisterDataPort 4
#define MainShiftRegisterClockPort 2
#define MainShiftRegisterLatchPort 3
#define LCDLatchPort 10

#define mp3TXPort 5
#define mp3RXPort 6
#define mp3PotentiometerPort 19 //A5

//For the bellow button port numbers, assume they are for Mux1 unless a comment indicates otherwise.

#define StartTestButtonPort 28

#define KeypadButtonReplayLastMessagePort 0
#define KeypadButton0Port 1
#define KeypadButton1Port 10
#define KeypadButton2Port 9
#define KeypadButton3Port 8
#define KeypadButton4Port 11
#define KeypadButton5Port 4
#define KeypadButton6Port 6
#define KeypadButton7Port 12
#define KeypadButton8Port 14
#define KeypadButton9Port 2


#define BookcasePressurePlatePort 30
#define BookcaseDoorServoPort 9

#define SundialButton1Port 26
#define SundialButton2Port 25
#define SundialButton3Port 24
#define SundialButton4Port 27

#define SundialLED1Port 3
#define SundialLED2Port 4
#define SundialLED3Port 5
#define SundialLED4Port 6
#define MainRoomLightLEDPort 7

#define SlidingBlocksButton1Port 18
#define SlidingBlocksButton2Port 17
#define SlidingBlocksButton3Port 16
#define SlidingBlocksButton4Port 19
#define SlidingBlocksButton5Port 20
#define SlidingBlocksButton6Port 22
#define SlidingBlocksButton7Port 23
#define SlidingBlocksButton8Port 21

#define SlidingBlocksServoPort 8
#define TrojanAndLogicServoPort 8

//Class definition of a Device:
class Device
{
    //Protected means that only this class or classes derived from it can use these.
    protected:
    int port; //Address of either the port in the Arduino or the mux
    const char* PROGMEM name; //Name used for logging/debugging

    //Public means any other class can use these.
    public:
    //Creates a Device with the specified port number and the name given to it.
    //(The name is to be used when writing to the Serial Monitor for debugging.)
    //The variables here must have different names than the ones that belong to the class.
    Device(const char* PROGMEM name_val, int port_num = 0);

    const char* PROGMEM Name(); //This function returns the name of the Device for debugging purposes.
};

//A DigitalSensor is derived from the Device class.
//This means that a DigitialSensor is a type of Device.
//A DigitalSensor is a type of Device that can read digital input and can be connected to the multiplexer or the Arduino.
//(The terms "mux" and "multiplexer" are used interchangeably.)
//(The mux this program uses allows up to 32 DigitalSensors to be used with only 6 Arduino Ports--5 for Selection Lines (2^5=32) and 1 for data.)
class DigitalSensor : public Device
{
    protected:
    int port_location, ArduinoPort;
    long previous_reading = 0;
    
    public:
    //An enum is a data type that sets the names in it to integer constants.
    enum PortLocation
    {
        AttachedDirectlyToArduino,
        Mux1
        //If more multiplexers are used, they can be added here.
    };

    //Creates a DigitalSensor. The port location (whether the DigitalSensor is attatched directly to the Arduino or to a Mux)
    //and the port number (0-13 if attatched directly to the Arduino or 0-31 if attatched to Mux1).
    DigitalSensor(const char* PROGMEM name_val, PortLocation port_location_val, int port_num);

    //Reads the input of the DigitalSensor and, if it is attatched to the mux, handles the selection of the input.
    long ReadInput();
};

class Button : public DigitalSensor
{
    protected:
    enum ButtonStateEnum
    {
        PRESSED = 0,
        RELEASED = 1
    };

    public:
    Button(const char* PROGMEM name_val, PortLocation port_location_val, int port_num, long initial_state_val = RELEASED);
    //initial_state_val will normally not be specified (default parameter), but for the pressure plate button should be filled with PRESSED

    bool RequestedButtonStateIsTrue(int state); //Used to account for debouncing.
    bool ButtonIsPressed();
    bool ButtonIsReleased();

    //Use to check whether the button was previously pressed when
    //whether the button changed state from pressed to released/released to pressed must be determined.
    bool ButtonWasPressed();
    
    void WaitForButtonState(int state); //Used to account for debouncing.
    void WaitForButtonPressed();
    void WaitForButtonReleased();
    void WaitForButtonClick(); //A "Click" is both a press and a release.
};

class LED : public Device
{
    protected:
    bool IsOn = false; //An LED stores whether it is on or not.
    int port_location;

    public:

    enum PortLocation
    {
        AttachedDirectlyToArduino,
        LEDBank
    };

    LED(const char* PROGMEM name_val, PortLocation port_location_val, int port_num);

    void TurnOnLED();
    void TurnOffLED();
    void ToggleLED(); //Changes the state of the LED
};

class EightBitShiftRegister : public Device
{
    protected:
    byte current_value;
    int latch_port, clock_port;
    
    public:
    EightBitShiftRegister(const char* PROGMEM name_val, int data_port_num, int latch_port_num, int clock_port_num);
    //The data port is stored in port in the Device class.

    void SetCurrentValue(byte value);
    byte GetCurrentValue();
};

//Two Eight Bit SN74HC595 Shift Registers daisy chained together
class SixteenBitShiftRegister : public Device
{
    EightBitShiftRegister shift_register;

    public:
    SixteenBitShiftRegister(const char* PROGMEM name_val, int data_port_num, int latch_port_num, int clock_port_num);

    void SetByte0(byte value);
    void SetByte1(byte value);
    byte GetByte0();
    byte GetByte1();

    protected:
    byte current_value_byte_0 = 0, current_value_byte_1 = 0; 
    //Feed in byte_0 (Seven Segment Display byte) first and then byte_1 (LED Bank byte).
};

extern SixteenBitShiftRegister TheSixteenBitShiftRegister; 
//extern means this variable will be exported out of this file--everywhere this file is included can use this variable

class LEDBank
{
    public:

    //static means these functions can only access static data members of the class
    //static data member means there is only one of that data member in the whole process
    //(this value is shared amongst all instances of the class)
    static void TurnOnLED(int index);
    static void TurnOffLED(int index);
    static void TurnOffAllLEDs();
};

class SevenSegmentDisplay
{
    public:

    static void DisplayDigit(int digit);
    static void TurnOffDisplay();
};

class AnalogSensor : public Device
{
    protected:
    int port_location;
    long previous_reading = 0;
    unsigned long time_of_previous_reading = 0;
    
    public:
    AnalogSensor(const char* PROGMEM name_val, int port_num);

    long ReadInput();
};

class MP3Potentiometer : public AnalogSensor
{
    public:
    MP3Potentiometer(const char* PROGMEM name_val, int port_num);
    int ReadPotentiometerAndConvertToSpeakerVolumeValues();
};

class ServoDevice : public Device
{
    protected:
    int intial_position;
    Servo myServo;

    public:
    ServoDevice(const char* PROGMEM name_val, int port_num, int initial_position_val);

    //Destructor
    //virtual so that if someone destroys a pointer to the base class (Devices), that will call this destructor for the ServoDevice
    //Use to detach the Servo after use to mitigate duration of servo vibrations
    virtual ~ServoDevice();

    void MoveToPosition(int angle);
    void MoveToInitialPosition();
};

#endif //This ends the #ifndef Devices_h