#ifndef Sundial_h
#define Sundial_h

#include "Task.h"

//Sundial is a type of Task that owns all of the Buttons, LEDs and functions needed for the Sundial Puzzle.
class Sundial : public Task
{
    public:
    Button SundialButton1;
    Button SundialButton2;
    Button SundialButton3;
    Button SundialButton4;

    LED SundialLED1;
    LED SundialLED2;
    LED SundialLED3;
    LED SundialLED4;
    LED MainRoomLightLED;

    SundialCommunicator sundial_communicator;

    Sundial();

    //Keeps checking all of the Buttons and carries out the appropriate responses to each input
    //(including turning on/off the corresponding LEDs)
    virtual void Run();

    //Checks whether a Button was pressed and then released.
    //If the Button has been clicked and the LED is on, turns the LED off.
    //If the Button has been clicked and the LED is off, turns the LED on.
    void ToggleLEDWhenButtonClicked(Button& button, LED& led);
};

#endif