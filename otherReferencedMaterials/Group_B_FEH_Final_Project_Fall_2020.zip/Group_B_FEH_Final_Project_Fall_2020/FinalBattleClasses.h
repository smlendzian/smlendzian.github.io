#ifndef FinalBattleClasses_h 
#define FinalBattleClasses_h

#include "Controls.h"
#include "Sprites.h"
#include <math.h>

#define ACCELERATION_OF_GRAVITY 9.8

//For clarity in the program, "player" refers to the person playing/the player slot they are using (ex. Arson), 
//and "character" refers to the character they play as in specifically the Final Battle (ex. Brooke).

//A ProjectileTextBox is a type of TextBox that moves in a path based on a projectile motion equation.
class ProjectileTextBox : public TextBox
{
    protected:
    
    public:

    //Creates ProjectileTextBox with coordinates x and y in the middle of the text (with the specified text color).
    ProjectileTextBox(const char*text_val, int x_val, int y_val, int color);

    //Animates the projectile motion.
    //Arguments: final x and y position, y position at the peak of the curve, time on screen before moving to next point (sec), color of the background
    //For time measurements, use a number with a decimal to ensure the function considers it a float.
    void Animate(int x_final, int y_final, int y_max, float time_interval, int background_color);
};

//A FinalBattleCharacter is a class that includes the functions, data/statistics, and Sprite for a character in the Final Battle.
class FinalBattleCharacter
{
   public:
   enum CharacterName
   {
      Brooke,
      Erin,
      Jimmy,
      Kyle,
      Riley,
      Gamer,
      TommPizza,
      Ladybug
   };
   
   protected:

   CharacterName character; 
   int health;

   const char*text;
   int x_i, y_i, x_f, y_f, y_max;
   float time_interval;
   int text_color, background_color;

   //TextBox character_sprite;
   CharacterSprite character_sprite;

   public:

   FinalBattleCharacter();

   void SetCharacter(CharacterName character_val, int initial_health);

   //Returns the value of the character variable.
   int GetCharacter();

   void SetHealth(int health_val);

   //Returns the character's current health.
   int GetHealth();

   void SubtractFromHealth(int health_lost);

   void AddToHealth(int health_gained);

   void SetProjectileText(const char*text_val);

   void SetProjectileTextInitialPosition(int x_i_val, int y_i_val);

   void SetProjectileTextFinalPosition(int x_f_val, int y_f_val);

   void SetProjectileTextMaxY(int y_max_val);

   void SetProjectileTextTimeInterval(float time_interval_val);

   void SetProjectileTextColors(int text_color_val, int background_color_val);

   virtual void SetProjectileTextBoxToDefault() = 0;

   //Attacks the other FinalBattleCharacter on the FinalBattleMainScreen with a ProjectileTextBox.
   //This function also carries out the effects of an attack.
   //Arguments: minimum amount of randomly generated base damage, maximum amount of randomly generated base damage, number the base damage is multiplied by (included for buffs/debuffs), and the miss rate (integer from 0 to 100)
   //Returns the amount of damage the attack did.
   int Attack(int min_base_damage, int max_base_damage, float multiplier, float power_multiplier, int miss_rate);

   //Heals the FinalBattleCharacter that uses it.
   //This function also carries out the effects of a heal.
   void Heal(int min_base_heal, int max_base_heal, float multiplier);

   virtual void DrawCharacter() = 0;

   virtual void UnDrawCharacter(int undraw_color) = 0;

   void DrawBoxAroundCharacter(int added_width, int added_height, int box_color);
};

//A FinalBattlePlayerCharacter is a FinalBattleCharacter for the player's character.
class FinalBattlePlayerCharacter : public FinalBattleCharacter
{
    private:
    //TextBox power_sprite;
    CharacterSprite power_sprite;
    
    public:
    FinalBattlePlayerCharacter();
    virtual void SetProjectileTextBoxToDefault();
    virtual void DrawCharacter();
    virtual void UnDrawCharacter(int undraw_color);
    void DrawBoxAroundPower(int added_width, int added_height, int box_color);
};

//A FinalBattleEnemyCharacter is a FinalBattleCharacter for the enemy's character.
class FinalBattleEnemyCharacter : public FinalBattleCharacter
{
    public:
    virtual void SetProjectileTextBoxToDefault();
    virtual void DrawCharacter();
    virtual void UnDrawCharacter(int undraw_color);
};

#endif