#include "Devices.h"

//Name for RAM conservation
const char PROGMEM TheSixteenBitShiftRegisterName[] = "TheSixteenBitShiftRegister";

SixteenBitShiftRegister TheSixteenBitShiftRegister(TheSixteenBitShiftRegisterName, MainShiftRegisterDataPort, MainShiftRegisterLatchPort, MainShiftRegisterClockPort);

//Constructor function for a Device
Device::Device(const char* PROGMEM name_val, int port_num)
:name(0), //Assigns the value in name_val to name (line ends with a comma) (has been changed to 0 for RAM conservation reasons)
port(port_num) //Assigns the value in port_num to port (line does not end with a comma because it is the last assignment in the list)
{

}

//Function belonging to the Device class that returns the name of the Device.
const char* PROGMEM Device::Name()
{
    return ""; //changed to return an empty string for RAM conservation
}

DigitalSensor::DigitalSensor(const char* PROGMEM name_val, PortLocation port_location_val, int port_num)
:Device(name_val, port_num), //Assigns the values for the variables that belong to the Device class that DigitalSensor is derived from
port_location(port_location_val)
{
    if(port_location == Mux1)
    {
        //Configure the mux select lines as outputs.
        pinMode(Mux1_S0_Port, OUTPUT);
        pinMode(Mux1_S1_Port, OUTPUT);
        pinMode(Mux1_S2_Port, OUTPUT);
        pinMode(Mux1_S3_Port, OUTPUT);
        pinMode(Mux1_S4_Port, OUTPUT);

        //The mux output is attatched to the ArduinoPort
        ArduinoPort = Mux1_SIG_Port;
    }
    else
    {
        //The DigitalSensor is attatched directly to the Arduino,
        //so port is the ArduinoPort
        ArduinoPort = port;
    }

    pinMode(ArduinoPort, INPUT_PULLUP); //Initialize the sensor as input pullup.
}

long DigitalSensor::ReadInput()
{
    long input_reading = 0;
    
    if(port_location == Mux1)
    {
        //Set the Mux Select Lines based on the port:

        //Uses Bitbanging (Bitwise AND):
        //Bitwise AND ands each bit in temp with each corresponding bit in the Mask (ex. 0b00001).
        //This ensures only the bit we are trying to write gets written.

        digitalWrite(Mux1_S0_Port, port & 0b00001);

        digitalWrite(Mux1_S1_Port, port & 0b00010);

        digitalWrite(Mux1_S2_Port, port & 0b00100);

        digitalWrite(Mux1_S3_Port, port & 0b01000);

        digitalWrite(Mux1_S4_Port, port & 0b10000);
    }

    input_reading = digitalRead(ArduinoPort);

    //For debugging:
    //Prints to the Serial Monitor the value of the sensor when the sensor value changes.
    if(input_reading != previous_reading)
    {
        if(port_location == Mux1)
        {
            Serial.print(Name());
            Serial.print(F(" MuxPort: "));
            Serial.print(port);
            Serial.print(F(" AduinoPort: "));
            Serial.print(ArduinoPort);
            Serial.print(F(" val: "));
            Serial.println(input_reading);
        }
        else
        {
            Serial.print(Name());
            Serial.print(F(" Port: "));
            Serial.print(ArduinoPort);
            Serial.print(F(" val: "));
            Serial.println(input_reading);
        }
        previous_reading = input_reading;
    }

    return input_reading;
}

Button::Button(const char* PROGMEM name_val, PortLocation port_location_val, int port_num, long initial_state_val)
:DigitalSensor(name_val, port_location_val, port_num)
{
    previous_reading = initial_state_val;
}

bool Button::RequestedButtonStateIsTrue(int state)
{
    //To account for debouncing, wait until after 5 consecutive readings of the requested button state.
    for(int count = 0; count < 5; ++count)
    {
        int reading = ReadInput();

        if(reading != state)
        {
            return false;
        }

        delay(1);     
    }
    return true;
}

bool Button::ButtonIsPressed()
{
    return RequestedButtonStateIsTrue(PRESSED);
}

bool Button::ButtonIsReleased()
{
    return RequestedButtonStateIsTrue(RELEASED);
}

bool Button::ButtonWasPressed()
{
    return previous_reading == PRESSED;
}

void Button::WaitForButtonState(int state)
{
    while(!RequestedButtonStateIsTrue(state));
}

void Button::WaitForButtonPressed()
{
    while(!ButtonIsPressed());
}

void Button::WaitForButtonReleased()
{
    while(!ButtonIsReleased());
}

void Button::WaitForButtonClick()
{
    WaitForButtonPressed();
    WaitForButtonReleased();
}

LED::LED(const char* PROGMEM name_val, PortLocation port_location_val, int port_num)
:Device(name_val, port_num),
port_location(port_location_val)
{
    if(port_location == AttachedDirectlyToArduino)
    {
        pinMode(port, OUTPUT);  //Initialize LED pin as an output pin.
    }
}

void LED::TurnOnLED()
{
    if(port_location == AttachedDirectlyToArduino)
    {
        digitalWrite(port, HIGH);
    }
    else
    {
        LEDBank::TurnOnLED(port);
    } 

    Serial.print(Name());
    Serial.print(F(": Port: "));
    Serial.print(port);
    Serial.println(F(" Was Turned On"));

    IsOn = true;
}

void LED::TurnOffLED()
{
    if(port_location == AttachedDirectlyToArduino)
    {
        digitalWrite(port, LOW);
    }
    else
    {
        LEDBank::TurnOffLED(port);
    }
    
    Serial.print(Name());
    Serial.print(F(": Port: "));
    Serial.print(port);
    Serial.println(F(" Was Turned Off"));

    IsOn = false;
}

void LED::ToggleLED()
{
    if(IsOn)
    {
        TurnOffLED();
    }
    else
    {
        TurnOnLED();
    }
}

EightBitShiftRegister::EightBitShiftRegister(const char* PROGMEM name_val, int data_port_num, int latch_port_num, int clock_port_num)
:Device(name_val, data_port_num),
latch_port(latch_port_num),
clock_port(clock_port_num)
{
    pinMode(port, OUTPUT);
    pinMode(latch_port, OUTPUT);
    pinMode(clock_port, OUTPUT);

    //Set the latch and clock port to LOW to start so they can take effect when transitioning to HIGH.
    digitalWrite(latch_port, LOW);
    digitalWrite(clock_port, LOW);
}

void EightBitShiftRegister::SetCurrentValue(byte value)
{
    current_value = value;

    //Shift the current value into the shift register
    for(int i = 0; i < 8; i++)
    {
        digitalWrite(port, value & 0b00000001);
        delayMicroseconds(1);
        
        digitalWrite(clock_port, HIGH);
        delayMicroseconds(1);
        
        digitalWrite(clock_port, LOW);
        digitalWrite(latch_port, HIGH);
        delayMicroseconds(1);
        
        digitalWrite(latch_port, LOW);
        value = value >> 1; //Bitwise Shift Right
    }
}

byte EightBitShiftRegister::GetCurrentValue()
{
    return current_value;
}

SixteenBitShiftRegister::SixteenBitShiftRegister(const char* PROGMEM name_val, int data_port_num, int latch_port_num, int clock_port_num)
:Device(name_val, data_port_num),
shift_register(name_val, data_port_num, latch_port_num, clock_port_num)
{
    //Clear LEDs and Seven Segment Display (turn everything off).
    shift_register.SetCurrentValue(current_value_byte_0);
    shift_register.SetCurrentValue(current_value_byte_1);
}

void SixteenBitShiftRegister::SetByte0(byte value)
{
    current_value_byte_0 = value;
    shift_register.SetCurrentValue(current_value_byte_0);
    shift_register.SetCurrentValue(current_value_byte_1);
}

void SixteenBitShiftRegister::SetByte1(byte value)
{
    current_value_byte_1 = value;
    shift_register.SetCurrentValue(current_value_byte_0);
    shift_register.SetCurrentValue(current_value_byte_1);
}

byte SixteenBitShiftRegister::GetByte0()
{
    return current_value_byte_0;
}

byte SixteenBitShiftRegister::GetByte1()
{
    return current_value_byte_1;
}

void LEDBank::TurnOnLED(int index)
{
    byte temp = 0b10000000;
    temp = temp >> index;
    
    byte byte1 = TheSixteenBitShiftRegister.GetByte1();
    byte1 = byte1 | temp; //Bitwise OR

    TheSixteenBitShiftRegister.SetByte1(byte1);
}

void LEDBank::TurnOffLED(int index)
{
    byte temp = 0b10000000;
    temp = temp >> index;
    temp = ~temp; //Bitwise Negation

    byte byte1 = TheSixteenBitShiftRegister.GetByte1();
    byte1 = byte1 & temp;

    TheSixteenBitShiftRegister.SetByte1(byte1);
}

void LEDBank::TurnOffAllLEDs()
{
    for(int i = 0; i <=8; i++)
    {
        TurnOffLED(i);
    }
}

void SevenSegmentDisplay::DisplayDigit(int digit)
{
    //                ABCDEFG.
    byte table[] = {0b11111100, 
                    0b01100000, 
                    0b11011010, 
                    0b11110010, 
                    0b01100110, 
                    0b10110110, 
                    0b10111110, 
                    0b11100000, 
                    0b11111110, 
                    0b11110110};

    TheSixteenBitShiftRegister.SetByte0(table[digit]);
}

void SevenSegmentDisplay::TurnOffDisplay()
{
    TheSixteenBitShiftRegister.SetByte0(0);
}

AnalogSensor::AnalogSensor(const char* PROGMEM name_val, int port_num)
:Device(name_val, port_num)
{
    pinMode(port, INPUT); //Initialize the sensor as input pullup.
}

long AnalogSensor::ReadInput()
{
    long input_reading = analogRead(port);
    long reading_change = input_reading - previous_reading;

    //For debugging:
    //Prints to the Serial Monitor the value of the sensor when the sensor value changes a significant amount
    if(abs(reading_change) > 30)
    {
        Serial.print(Name());
        Serial.print(F(" Port: "));
        Serial.print(port);
        Serial.print(F(" val: "));
        Serial.println(input_reading);

        previous_reading = input_reading;
    }

    return input_reading;
}

MP3Potentiometer::MP3Potentiometer(const char* PROGMEM name_val, int port_num)
:AnalogSensor(name_val, port_num)
{
    
}

int MP3Potentiometer::ReadPotentiometerAndConvertToSpeakerVolumeValues()
{
    int previous_reading_val = previous_reading;
    long input_reading = ReadInput();
    long reading_change = input_reading - previous_reading_val;

    //The MP3 Player module takes volume values from 0 to 30
    //and the potentiometer returns values between 0 and 1023
    int speaker_volume_value = input_reading * 30 / 1023;

    return speaker_volume_value;
}

ServoDevice::ServoDevice(const char* PROGMEM name_val, int port_num, int initial_position_val)
:Device(name_val, port_num),
intial_position(initial_position_val)
{
    myServo.attach(port);
}

ServoDevice::~ServoDevice()
{
    myServo.detach();
}

void ServoDevice::MoveToInitialPosition()
{
    MoveToPosition(intial_position);
}

void ServoDevice::MoveToPosition(int angle)
{
    myServo.write(angle);
    Serial.print(Name());
    Serial.print(F(" WasMovedTo: "));
    Serial.println(angle);
}