#include "Bookcase.h"

//Name list for RAM conservation
const char PROGMEM BookcaseName[] = "Bookcase";
const char PROGMEM PressurePlateName[] = "PressurePlate";
const char PROGMEM BookcaseServoName[] = "BookcaseServo";

Bookcase::Bookcase()
:Task(BookcaseName),
PressurePlate(PressurePlateName, DigitalSensor::Mux1, BookcasePressurePlatePort)
{
    //Everything in this constructor is carried out when an instance of the Bookcase class is created.
}

void Bookcase::Run()
{
    while(!ShouldEndTask) //Loop is redundant but used for clarity
    {
        if(PressurePlate.ButtonIsReleased())
        {
            Serial.println(F("PressurePlateReleased"));

            {
                ServoDevice bookcase_servo(BookcaseServoName, BookcaseDoorServoPort, 0);
                bookcase_servo.MoveToPosition(90); //Servo moves the door 90 degrees into its "open" position.
                delay(3000);
            } //ServoDevice destructor is called after the closing curly brace

            Serial.println(F("ServoMotorToOpenedPosition"));

            ShouldEndTask = true; //Ends the loop in Task::Start() to return to the MainMenu
        }

    }
}