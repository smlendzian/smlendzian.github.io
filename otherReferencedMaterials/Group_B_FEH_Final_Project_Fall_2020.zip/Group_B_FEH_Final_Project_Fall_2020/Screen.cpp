#include "Screen.h"

Screen::Screen()
:ShouldExitScreen(false)
{

}

void Screen::StartScreen()
{
    ShouldExitScreen = false;

    first_draw = true;
    
    while(!ShouldExitScreen)
    {
        DrawScreen();
        first_draw = false;
        
        int x, y;
        while (!LCD.Touch(&x, &y))
        {
        }
        ScreenTouched(x,y);
    }
}