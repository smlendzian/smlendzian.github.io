#ifndef StatsScreen_h 
#define StatsScreen_h 

#include "Screen.h"
#include "TeaTimeScreen.h"

//The StatsScreen is drawn after the appropriate Button is clicked on the MenuScreen.
//The statistics for the current player slot are displayed here.
//The player can return to the MenuScreen.
class StatsScreen : public Screen 
{
   private:
   TextBox statistics, player_text, player_val_text;
   TextBox spot_speed_text, spot_speed_val_text;
   TextBox aerodynamics_text, aerodynamics_val_text; 
   TextBox final_battle_text, final_battle_val_text;
   Button X;
   ConditionalButton tea_time;

   TeaTimeScreen tea_time_screen;

   public:

   StatsScreen();

   virtual void DrawScreen();
   virtual void ScreenTouched(int x, int y);
};

#endif