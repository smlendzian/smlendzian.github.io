#include "FEHLCD.h"
#include "PlayerScreen.h"
#include "Stats.h"

int main() 
{
    LCD.Clear();
    LCD.ClearBuffer();

    Stats::Instance().Load();

    PlayerScreen screen;
    screen.StartScreen();

    return 0;
}