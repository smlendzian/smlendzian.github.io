#ifndef FinalBattleCharcaterSelectScreen_h 
#define FinalBattleCharacterSelectScreen_h 

#include "Screen.h"
#include "FinalBattleMainScreen.h"

//This Screen is the first the player will see after pressing the Final Battle Button on the MenuScreen (assuming it is enabled).
//It allows the player to click on the character they want to play as in the Final Battle (based on which character Buttons are enabled).
//After a Button is clicked, the FinalBattleMainScreen will be brought up.
class FinalBattleCharacterSelectScreen : public Screen 
{
   private:
   TextBox ChooseCharacter;
   Button X;
   ConditionalButton BrookeButton, ErinButton, JimmyButton, KyleButton, RileyButton;
   FinalBattleMainScreen final_battle_go;

   public:

   FinalBattleCharacterSelectScreen();

   virtual void DrawScreen();
   virtual void ScreenTouched(int x, int y);
};

#endif