#ifndef SpotSpeedScreen_h 
#define SpotSpeedScreen_h 

#include "Screen.h"
#include "SpotSpeedGameScreen.h"

/*This is the class for the buttons and textboxes on the spot speed main screen before the game*/
class SpotSpeedScreen : public Screen 
{
   private: 
   Button X;
   Button StartSpot;
   TextBox SpotSpeed;
   TextBox SSInstructions;
   TextBox SSInstructionstwo;
   TextBox SSInstructionsthree;
   TextBox SSInstructionsfour;

   protected:
   SpotSpeedGameScreen Spot;

   public:

   SpotSpeedScreen();

   virtual void DrawScreen();
   virtual void ScreenTouched(int x, int y);
};

#endif