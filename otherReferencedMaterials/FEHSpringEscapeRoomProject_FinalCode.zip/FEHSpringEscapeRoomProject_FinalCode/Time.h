#ifndef Time_h
#define Time_h

#include <Arduino.h>

//From https://github.com/mpflaga/Arduino-MemoryFree
//to help with RAM usage
#include <MemoryFree.h>
#include <pgmStrToRAM.h>
//Use F("String") for print statements to free up RAM.

#define MillisecondsInAMinute 60000
#define MillisecondsInASecond 1000
#define EscapeRoomTimeLimit 30 //in minutes

//Time handles keeping track of time in the Escape Room.
class Time
{
    //unsigned long is recommended for variables holding time and is the data type millis() returns
    //unsigned long TimeInMillisecondsSinceEscapeRoomStarted;
    unsigned long ProgramTimeAtLastReset; //Time millis() returned when ResetTimeSinceEscapeRoomStarted() was last called

    public:
    void ResetTimeSinceEscapeRoomStarted();
    unsigned long GetTimeSinceEscapeRoomStartedInMilliseconds();

    bool TimeHasNotRunOut();
    unsigned long GetTimeLeftInEscapeRoomInMilliseconds();
};

//extern means this variable will be exported out of this file--everywhere this file is included can use this variable
extern Time TheTime;

#endif