#include "SpotSpeedGameScreen.h"
#include "FEHLCD.h"
#include "Controls.h"
#include "Screen.h"

/*This will display text to the game play screen and has the exist button */

SpotSpeedGameScreen::SpotSpeedGameScreen()
:SpotSpeed("Spot Speed Game Screen", MAX_X/2, CHAR_HEIGHT/2 + 4, MAX_X, CHAR_HEIGHT, BLACK),
 X("X", MAX_X - CHAR_WIDTH, 4, CHAR_WIDTH, CHAR_HEIGHT, BLACK, MAROON, MAROON),
 Press("X", 160, 160, CHAR_WIDTH, CHAR_HEIGHT, BLACK, WHITE, WHITE)

 
 
{

}

/*This will have the drawings of the game play*/

void SpotSpeedGameScreen::DrawScreen()
{
    /*Has the variables that will be used*/

    int a, b, c, d, e=160, f=160, points=0, total_points=0;

    for (d=1; d<6; d++)
    {

    /*This is the background of the game, that will stay constant for the whole game*/

    LCD.Clear(SKYBLUE);
    SpotSpeed.Draw();
    X.Draw();
    Press.Draw();

    /*The background in this case is a road since this game is relating to the mini game that 
    we measured the speed of cars as they drove past*/

    /*This section of the code is for the bottom of the road*/
    
    for (a=240; a>=230; a--)
    {
    LCD.SetDrawColor(GRAY);
    LCD.DrawLine(0, a, 320, a);
    }

    /*This section of the code is for the middle of the road and the stripes*/

    for (a=232; a>=225; a--)
    {
    LCD.SetDrawColor(YELLOW);
    LCD.DrawLine(0, a, 64, a);
    LCD.DrawLine(128, a, 192, a);
    LCD.DrawLine(256, a, 320, a);
    LCD.SetDrawColor(GRAY);
    LCD.DrawLine(64, a, 128, a);
    LCD.DrawLine(192, a, 256, a);
    }

    /*This is the top layer of the road*/
    
    for(a=224; a>=214; a--)
    {
    LCD.SetDrawColor(GRAY);
    LCD.DrawLine(0, a, 320, a);
    }

/*This is where the words at the beginning of each line are displayed to the screen*/

    LCD.SetFontColor(WHITE);
    LCD.WriteAt("Round: ", 120.5, 44.5);
    LCD.WriteAt(d, 180, 45.5);
    Sleep(1.0);
    LCD.WriteAt("Ready?", 126, 74.5);
    Sleep(1.0);
    LCD.WriteAt("Set?", 131, 104.5);
    Sleep(1.0);
    LCD.WriteAt("GO!", 133, 134.5);
    Sleep(.5);

/*This is where the shapes and colors for the car are created with their dimentions*/

    LCD.SetDrawColor(BLACK);
    LCD.FillCircle(13, 202, 12.5);
    LCD.FillCircle(63, 202, 12.5);
    LCD.SetDrawColor(SCARLET);
    LCD.FillRectangle(13, 170, 50, 30);
    b=1;
    c=13;

    /*This while loop is to make the car 'move' across the screen by covering up the old shapes with the background and having the new car be moved up a few spots*/
        while (b<20)
        {   
            Sleep(.3/d);
            LCD.SetDrawColor(SKYBLUE);
            LCD.FillCircle(13+(c-13), 202, 12.5);
            LCD.FillCircle(63+(c-13), 202, 12.5);
            LCD.SetDrawColor(SKYBLUE);
            LCD.FillRectangle(13+(c-13), 170, 50, 30);
            LCD.SetDrawColor(BLACK);
            LCD.FillCircle(13+c, 202, 12.5);
            LCD.FillCircle(63+c, 202, 12.5);
            LCD.SetDrawColor(SCARLET);
            LCD.FillRectangle(13+c, 170, 50, 30); 
            b=b+1;
            c=c+13;


            /*What happens if the screen is touched in the middle of the round
            If the box is touched at the correct time, a point is added*/
                if (LCD.Touch(&e, &f))
                {
                LCD.ClearBuffer();
                if (b==9)
                {
                points=points+1;
                Sleep(.5);
                LCD.ClearBuffer();
                while (b<20)
                {
                Sleep(.3/d);
                LCD.SetDrawColor(SKYBLUE);
                LCD.FillCircle(13+(c-13), 202, 12.5);
                LCD.FillCircle(63+(c-13), 202, 12.5);
                LCD.SetDrawColor(SKYBLUE);
                LCD.FillRectangle(13+(c-13), 170, 50, 30);
                LCD.SetDrawColor(BLACK);
                LCD.FillCircle(13+c, 202, 12.5);
                LCD.FillCircle(63+c, 202, 12.5);
                LCD.SetDrawColor(SCARLET);
                LCD.FillRectangle(13+c, 170, 50, 30);
                b=b+1;
                c=c+13;
                }
                }
            
                }
                /*What happens if the screen is not touched in the middle of the round
                There are no points being added up and the game finishes the round */
                else
                {
                    if (b==9)
                    {
                    LCD.SetDrawColor(SKYBLUE);
                    LCD.FillCircle(13+(c-13), 202, 12.5);
                    LCD.FillCircle(63+(c-13), 202, 12.5);
                    LCD.SetDrawColor(SKYBLUE);
                    LCD.FillRectangle(13+(c-13), 170, 50, 30);
                    b=b+1;
                    c=c+13;
                    while (b<20)
                    {   
                    Sleep(.3/d);
                    LCD.SetDrawColor(SKYBLUE);
                    LCD.FillCircle(13+(c-13), 202, 12.5);
                    LCD.FillCircle(63+(c-13), 202, 12.5);
                    LCD.SetDrawColor(SKYBLUE);
                    LCD.FillRectangle(13+(c-13), 170, 50, 30);
                    LCD.SetDrawColor(BLACK);
                    LCD.FillCircle(13+c, 202, 12.5);
                    LCD.FillCircle(63+c, 202, 12.5);
                    LCD.SetDrawColor(SCARLET);
                    LCD.FillRectangle(13+c, 170, 50, 30); 
                    b=b+1;
                    c=c+13;
                    }
                    }
                }
         
            }

/*This is the ending screen that reminds the player that the round is over*/
        LCD.Clear(MAROON);
        LCD.SetFontColor(WHITE);
        LCD.WriteAt("Round ", 100, 74.5);
        LCD.WriteAt(d, 155.5, 75.5);
        LCD.WriteAt(" is over!", 165, 74.5 );
        LCD.WriteAt("Total Points Earned: ", 70, 94.5);
        LCD.WriteAt(points, 240, 95.5);
        X.Draw();
        Sleep(2.0);
        LCD.Clear();

    }   
    /*This is the final screen that the player sees before they can exist the game
    It tells the player that the game has ended, their total number of points, 
    a nice message and if they "won" the game or not*/
    total_points=total_points+points; 
    LCD.Clear(MAROON);
    LCD.SetFontColor(WHITE);
    LCD.WriteAt("The Game Has Ended!", 80, 74.5);
    LCD.WriteAt("Total Points: ", 85, 104.5);
    LCD.WriteAt(total_points, 195, 105.5);
    LCD.WriteAt("I Hope You Enjoyed It! :)", 75, 134.5);
        if (points==5)
        {
            LCD.WriteAt("You Have Won!", 90, 180);
            Stats::Instance().GetCurrentPlayerStats().spot_speed_points++;
            Stats::Instance().Save();
        }
        else
        {
            LCD.WriteAt("You Have Not Won :(", 80, 180);
        }
        
    Sleep(5.0);
    X.Draw();

   
}

/*This will redirect the player to the main screen of this game when the x is touched 
when the game is over*/
void SpotSpeedGameScreen::ScreenTouched(int x, int y)
{
   if(X.WasControlTouched(x,y))
   {
       ShouldExitScreen = true;
   }
}