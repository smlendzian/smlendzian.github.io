#ifndef Sprites_h 
#define Sprites_h

#include <vector>

#include "Controls.h"

using namespace std;

//A Sprite is a 2-Dimensional Array of pixels.
class Sprite : public Control
{
    protected:

    vector< vector<int> > array;

    public:

    //Creates Sprite with coordinates x and y in the middle of the Sprite with the specified number of rows (w) and columns (h) of pixels.
    Sprite(int x_val, int y_val, int w, int h);

    //Draws the Sprite on the Screen.
    virtual void Draw();
};

class CharacterSprite : public Sprite
{
    public:
    enum CharacterSpriteName
    {
      Brooke,
      Erin,
      Jimmy,
      Kyle,
      Riley,
      Gamer,
      TommPizza,
      Ladybug,
      Cat,
      Oatmeal,
      Eggo,
      Teleport,
      Coffee
   };

   CharacterSprite(CharacterSpriteName character_sprite_name, int x_val, int y_val, int scaling_factor_val);

   virtual void Draw();

   protected:
   int scaling_factor;
};

//A TeacupSprite is a type of Sprite that draws a teacup.
class TeacupSprite : public Sprite
{
    public:

    //Creates TeacupSprite with coordinates x and y in the middle of the Sprite
    TeacupSprite(int x_val, int y_val);
};

//A QRSprite is a type of Sprite that draws the QR code for Drew's video.
class QRSprite : public Sprite
{
    public:

    //Creates QRSprite with coordinates x and y in the middle of the Sprite
    QRSprite(int x_val, int y_val, int scaling_factor_val);

    virtual void Draw();

    protected:
    int scaling_factor;
};

#endif