#include "Time.h"

Time TheTime;

void Time::ResetTimeSinceEscapeRoomStarted()
{
    ProgramTimeAtLastReset = millis();
}

unsigned long Time::GetTimeSinceEscapeRoomStartedInMilliseconds()
{
    return millis() - ProgramTimeAtLastReset;
}

bool Time::TimeHasNotRunOut()
{
    return 0 <= 
            (MillisecondsInAMinute * EscapeRoomTimeLimit - GetTimeSinceEscapeRoomStartedInMilliseconds()) 
            <= EscapeRoomTimeLimit;
}

unsigned long Time::GetTimeLeftInEscapeRoomInMilliseconds()
{
    if(TimeHasNotRunOut())
    {
        return MillisecondsInAMinute * EscapeRoomTimeLimit - GetTimeSinceEscapeRoomStartedInMilliseconds();
    }
    else
    {
        return 0;
    }
}



