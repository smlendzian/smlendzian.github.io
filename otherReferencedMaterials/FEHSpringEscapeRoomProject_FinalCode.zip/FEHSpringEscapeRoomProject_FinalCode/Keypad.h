#ifndef Keypad_h
#define Keypad_h

#include "Devices.h"

class KeypadButton : public Button
{
    protected:

    bool buttonWasClicked = false;
    int button_number;

    public:
    KeypadButton(const char* PROGMEM name_val, PortLocation port_location_val, int port_num, int button_num, long initial_state_val = RELEASED);

    //Checks each button to see if it was clicked
    bool GetButtonWasClicked();

    //After a button is clicked, which button was clicked is returned
    int GetButtonNumber();

    void SetButtonWasClicked(bool button_was_pressed_correctly_val);

    void CheckIfButtonWasClicked();
};

//Keypad is a type of Task that owns all of the Buttons(keys) and functions needed for the Keypad.
class Keypad
{
    public:
    KeypadButton KeypadButton0;
    KeypadButton KeypadButton1;
    KeypadButton KeypadButton2;
    KeypadButton KeypadButton3;
    KeypadButton KeypadButton4;
    KeypadButton KeypadButton5;
    KeypadButton KeypadButton6;
    KeypadButton KeypadButton7;
    KeypadButton KeypadButton8;
    KeypadButton KeypadButton9;
    KeypadButton KeypadButtonReplayLastMessage;

    Keypad(const char* PROGMEM name_val = "Keypad");

    int Run();
    int CheckButton(KeypadButton& button);
    bool ANumberButtonWasClicked();
};

#endif