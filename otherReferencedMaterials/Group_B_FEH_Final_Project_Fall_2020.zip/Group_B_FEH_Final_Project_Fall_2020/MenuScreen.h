#ifndef MenuScreen_h 
#define MenuScreen_h 

#include "Screen.h"
#include "MainInstructionsScreen.h"
#include "StatsScreen.h"
#include "MinigamesMenuScreen.h"
#include "FinalBattleCharacterSelectScreen.h"

//After choosing the player slot, this Screen will come up.
//From this Screen, the player can click the appropriate Button to go to the
//MainInstructionsScreen,
//StatsScreen,
//MinigamesMenuScreen,
//and Final Battle if the player has unlocked it (NOT CODED YET),
//or the player can return to the PlayerScreen
class MenuScreen : public Screen 
{
   protected:
   TextBox Title;
   Button Instructions, StatsText, Minigames, Choose_Different_Player;
   ConditionalButton Final_Battle;

   MainInstructionsScreen instructions;
   StatsScreen stats_screen;
   MinigamesMenuScreen mini_menu;
   FinalBattleCharacterSelectScreen final_battle;

   public:

    MenuScreen();

    virtual void DrawScreen();
    virtual void ScreenTouched(int x, int y);
};

#endif