#include "StatsScreen.h"

StatsScreen::StatsScreen()
:statistics("Statistics", MAX_X/2, 10, MAX_X, CHAR_HEIGHT, LCD.Black),
 player_text("Player:", MAX_X/2, 40, MAX_X, CHAR_HEIGHT, LCD.Black),
 player_val_text(" ", MAX_X/2 - 30, 60, MAX_X, CHAR_HEIGHT, LCD.Black),
 spot_speed_text("Spot Speed Minigame Wins:", MAX_X/2, 80, MAX_X, CHAR_HEIGHT, LCD.Black),
 spot_speed_val_text(" ", MAX_X/2, 100, MAX_X, CHAR_HEIGHT, LCD.Black),
 aerodynamics_text("Aerodynamics Minigame Wins:", MAX_X/2, 120, MAX_X, CHAR_HEIGHT, LCD.Black),
 aerodynamics_val_text(" ", MAX_X/2, 140, MAX_X, CHAR_HEIGHT, LCD.Black),
 final_battle_text("Final Battle Wins:", MAX_X/2, 160, MAX_X, CHAR_HEIGHT, LCD.Black),
 final_battle_val_text(" ", MAX_X/2, 180, MAX_X, CHAR_HEIGHT, LCD.Black),
 tea_time("Extra Tea Time With Drew", MAX_X/2, 210, 250, 30, LCD.Black, LCD.Black, LCD.White, LCD.Gray),
 X("X", MAX_X - CHAR_WIDTH, 4, CHAR_WIDTH, CHAR_HEIGHT, LCD.Black, LCD.Red, LCD.Red)
{

}

void StatsScreen::DrawScreen()
{
    LCD.Clear(LCD.Red);

    Stats& stats = Stats::Instance();
    
    player_val_text.SetText(stats.GetPlayerNameText().c_str());
    spot_speed_val_text.SetText(stats.GetCurrentPlayerStats().spot_speed_points);
    aerodynamics_val_text.SetText(stats.GetCurrentPlayerStats().aerodynamics_points);
    final_battle_val_text.SetText(stats.GetCurrentPlayerStats().final_battle_wins);

    if(stats.GetCurrentPlayerStats().final_battle_wins < 1)
        tea_time.SetEnabled(false);
    else
        tea_time.SetEnabled(true);
    
    statistics.Draw();
    player_text.Draw();
    player_val_text.Draw();
    spot_speed_text.Draw();
    spot_speed_val_text.Draw();
    aerodynamics_text.Draw();
    aerodynamics_val_text.Draw();
    final_battle_text.Draw();
    final_battle_val_text.Draw();
    tea_time.Draw();
    X.Draw();
}

void StatsScreen::ScreenTouched(int x, int y)
{
   if(X.WasControlTouched(x,y))
   {
       ShouldExitScreen = true;
   }
   else if (tea_time.WasControlTouched(x,y))
   {
       tea_time_screen.StartScreen();
   }
}